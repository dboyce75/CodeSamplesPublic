﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SystemFrameworks;

namespace DataLayer
{
    interface IData
    {
        void LogFileReceipt(string fileName);
        bool CheckForDuplicateFile(string fileName);
        void LoadIncomingShippingRecords(ShippingRecord inShippingRecord, string fileBeingProcessed);
        List<SageDetail> GetScrubbedData();
        void FinalizeOrders();
        void TruncateStagingTable();
        void UpdateTrackingStatus(string orderNumber, string retVal);

    }
}
