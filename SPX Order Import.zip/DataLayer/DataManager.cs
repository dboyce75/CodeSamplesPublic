﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SystemFrameworks;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Data;
using System.Configuration;
using Utilities;

namespace DataLayer
{
    public class DataManager : IData
    {

        public void LogFileReceipt(string fileName) { }
        
        public bool CheckForDuplicateFile(string fileName) 
        {
            // todo - this might not be needed...
            return false;
        }
        
        public void LoadIncomingShippingRecords(ShippingRecord inShippingRecord, string fileBeingProcessed)
        {
            SqlCommand cmd = null;
            SqlConnection connx = null;
            try
            {
                using (connx = getConnection())
                {
                    using (cmd = getCommand("InsertRow"))
                    {
                        cmd.Parameters.Add("@FileName", SqlDbType.VarChar).Value = fileBeingProcessed;
                        cmd.Parameters.Add("@FileDate", SqlDbType.VarChar).Value = DateTime.Now.ToString();
                        cmd.Parameters.Add("@TrackingNumber", SqlDbType.VarChar).Value = inShippingRecord.TrackingID;
                        cmd.Parameters.Add("@ShipDate", SqlDbType.VarChar).Value = inShippingRecord.ShipDate;
                        cmd.Parameters.Add("@ShipCarrier", SqlDbType.VarChar).Value = inShippingRecord.ShipCarrier;
                        cmd.Parameters.Add("@ShipSrvCode", SqlDbType.VarChar).Value = inShippingRecord.ShipSvcCode;
                        cmd.Parameters.Add("@Act_Wgt", SqlDbType.VarChar).Value = inShippingRecord.ActualWeight;
                        cmd.Parameters.Add("@Customer", SqlDbType.VarChar).Value = inShippingRecord.Customer;
                        cmd.Parameters.Add("@Facility", SqlDbType.VarChar).Value = inShippingRecord.Facility;
                        cmd.Parameters.Add("@OrderNbr", SqlDbType.VarChar).Value = inShippingRecord.OrderNumber;
                        cmd.Parameters.Add("@ReferenceNbr", SqlDbType.VarChar).Value = inShippingRecord.ReferenceNumber;
                        cmd.Parameters.Add("@PONumber", SqlDbType.VarChar).Value = inShippingRecord.PONumber;
                        cmd.Parameters.Add("@DepartmentID", SqlDbType.VarChar).Value = inShippingRecord.DepartmentID;
                        cmd.Parameters.Add("@ReferenceNbr2", SqlDbType.VarChar).Value = inShippingRecord.ReferenceNumber2;
                        cmd.Parameters.Add("@ShipContact", SqlDbType.VarChar).Value = inShippingRecord.ShipContact;
                        cmd.Parameters.Add("@ShipCompany", SqlDbType.VarChar).Value = inShippingRecord.ShipCompany;
                        cmd.Parameters.Add("@ShipAddress1", SqlDbType.VarChar).Value = inShippingRecord.ShipAddress1;
                        cmd.Parameters.Add("@ShipAddress2", SqlDbType.VarChar).Value = inShippingRecord.ShipAddress2;
                        cmd.Parameters.Add("@ShipCity", SqlDbType.VarChar).Value = inShippingRecord.ShipCity;
                        cmd.Parameters.Add("@ShipState", SqlDbType.VarChar).Value = inShippingRecord.ShipState;
                        cmd.Parameters.Add("@ShipZipCode", SqlDbType.VarChar).Value = inShippingRecord.ShipZip;
                        cmd.Parameters.Add("@SHIPCOUNTRY", SqlDbType.VarChar).Value = inShippingRecord.ShipCountry;
                        cmd.Parameters.Add("@Item", SqlDbType.VarChar).Value = inShippingRecord.Item;
                        cmd.Parameters.Add("@QUantity", SqlDbType.VarChar).Value = inShippingRecord.Quantity;
                        cmd.Parameters.Add("@UnitOfMeasure", SqlDbType.VarChar).Value = inShippingRecord.UnitOfMeasure;
                        cmd.Parameters.Add("@HdrPassthruChar06", SqlDbType.VarChar).Value = inShippingRecord.PassThruChar06;
                        cmd.Parameters.Add("@LotNumber", SqlDbType.VarChar).Value = inShippingRecord.LotNumber;
                        cmd.Parameters.Add("@ShipId", SqlDbType.VarChar).Value = inShippingRecord.ShipID;
                        cmd.Parameters.Add("@DTLPASSTHRUCHAR10", SqlDbType.VarChar).Value = inShippingRecord.PassThruChar10;
                        cmd.Parameters.Add("@DTLPASSTHRUCHAR11", SqlDbType.VarChar).Value = inShippingRecord.PassThruChar11;
                        cmd.Parameters.Add("@DTLPASSTHRUCHAR08", SqlDbType.VarChar).Value = inShippingRecord.PassThruChar8;

                        cmd.Connection = connx;
                        cmd.CommandType = CommandType.StoredProcedure;
                        connx.Open();

                        int retVal = Convert.ToInt32(cmd.ExecuteNonQuery());
                    }
                }
            }
            catch (Exception ex)
            {
                Utils uu = new Utils();
                uu.GenerateCaughtException("Data Layer - Load Incoming Records ", ex);
            }
        }

        public List<SageDetail> GetScrubbedData()
        {
            List<SageDetail> lstSageDetail = new List<SageDetail>();

            SqlCommand cmd = null;
            SqlConnection connx = null;
            try
            {
                using (connx = getConnection())
                {
                    using (cmd = new SqlCommand("Dataload.SPXTrackingImportScrub"))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection = connx;
                        cmd.CommandTimeout = 0;
                        connx.Open();
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                SageDetail sd = new SageDetail();
                                sd.BatchID = dr["BatchID"].ToString();
                                sd.OrderNumber = dr["OrderNo"].ToString();
                                sd.InvoiceNumber = dr["InvoiceNo"].ToString();
                                sd.CustomerNumber = dr["CustNo"].ToString();
                                sd.ShipDate = dr["SHIPDATE"].ToString();
                                sd.ShipVia = dr["SageShipVia"].ToString();
                                lstSageDetail.Add(sd);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils uu = new Utils();
                uu.GenerateCaughtException("Data Layer - GetScrubbed Data ", ex);
            }
           
            return lstSageDetail;
        }
        
        public void FinalizeOrders()
        {

            SqlCommand cmd = null;
            SqlConnection connx = null;
            string retVal = "";
            try
            {
                using (connx = getConnection())
                {
                    using (cmd = new SqlCommand("Dataload.SPXTrackingImportFinalize"))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection = connx;
                        cmd.CommandTimeout = 0;
                        connx.Open();

                        retVal = cmd.ExecuteNonQuery().ToString();
                    }
                }
                Console.WriteLine(retVal + " rows Finalized");
            }
            catch (Exception ex)
            {
                Utils uu = new Utils();
                uu.GenerateCaughtException("Data Layer - Finalize Orders ", ex);
            }
        }

        public void UpdateTrackingStatus(string orderNumber, string retVal)
        {
            SqlCommand cmd = null;
            SqlConnection connx = null;
            try
            {
                using (connx = getConnection())
                {
                    using (cmd = new SqlCommand("Dataload.SPXTrackingImportUpdate"))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@OrderNo", SqlDbType.VarChar).Value = orderNumber;
                        cmd.Parameters.Add("@Message", SqlDbType.VarChar).Value = retVal;
                        cmd.Connection = connx;
                        connx.Open();
                        int rtv = cmd.ExecuteNonQuery();
                        if (rtv == 0)
                        {
                            // update failed
                        }
                    }
                }
             }
            catch (Exception ex)
            {
                Utils uu = new Utils();
                uu.GenerateCaughtException("Data Layer - Update Tracking Status ", ex);
            }
        }

        public void TruncateStagingTable()
        {
            SqlCommand cmd = null;
            SqlConnection connx = null;
            try
            {
                using (connx = getConnection())
                {
                    using (cmd = getCommand("NewFile")) 
                    {
                        cmd.Connection = connx;
                        cmd.CommandType = CommandType.StoredProcedure;
                        connx.Open();

                        string retVal = cmd.ExecuteNonQuery().ToString();
                        Console.WriteLine(retVal + " rows deleted in truncate step");
                    }
                }
                
            }
            catch (Exception ex)
            {
                Utils uu = new Utils();
                uu.GenerateCaughtException("Data Layer - Truncate Staging Table ", ex);
            }
        }

        private SqlConnection getConnection()
        {
            string cxString = ConfigurationManager.ConnectionStrings["DWConnx"].ConnectionString;
            SqlConnection connx = new SqlConnection(cxString);
            return connx;
        }

        private SqlCommand getCommand(string sectionName)
        {
            SqlCommand cmd = new SqlCommand("Dataload.SPXTrackingImportInsert");
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@Section", SqlDbType.VarChar).Value = sectionName;
            return cmd;

        }
    }
}
