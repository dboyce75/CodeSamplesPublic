﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BusinessLayer;
using System.Configuration;
using SystemFrameworks;
using Utilities;




namespace SPXOrderImport
{
    class SPXOrderImport
     {
        static void Main(string[] args)
        {
            BusinessManager iBo = new BusinessManager();
            string skipFTP = ConfigurationManager.AppSettings["SkipFTPStep"].ToString();
            
            try
            {
                // this is the thread exception handler
                AppDomain curDomain = AppDomain.CurrentDomain;
                curDomain.UnhandledException += new UnhandledExceptionEventHandler(SPXOrderImport_UnhandledException);
                
                // get list of files to process
                List<string> lstUploadedFiles = iBo.FileSweeper();

                foreach (string f in lstUploadedFiles)
                {
                    // handle each file seperately
                    List<ShippingRecord> lstShippingRecords = iBo.ExtractUploadedData(f);
                    iBo.StageUploadedData(lstShippingRecords, f);
                    List<SageDetail> lstValidShippingRecords = iBo.ValidateUploadedData(); // only valid records are returned in this step
                    iBo.CallSageComponent(lstValidShippingRecords);
                    iBo.FinalizeOrders();
                    iBo.MoveFTPFileToArchive(f);
                    iBo.MoveFileToNetworkShare(f);

                }               
            }
            catch (Exception ex)
            {
                // this is to catch any single threaded exceptions
               Utils uu = new Utils();
               uu.GenerateCaughtException("Generic Unhandled exception occurred", ex);


                
            }
            finally
            {
                Console.WriteLine("Fin.");
            }
        }

        static void SPXOrderImport_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            // this is to catch any exceptions in threading
            Console.WriteLine("in Unhandled exception block");
        }

       
    }
}
