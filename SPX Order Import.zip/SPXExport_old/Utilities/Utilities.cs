﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Utilities
{
    public class Utilities
    {
        public void GenerateCaughtException()
        {

        }

        public void GenerateUnhandledException()
        { 

        }
    }
}
