﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BusinessLayer;
using System.Configuration;
using SystemFrameworks;



namespace SPXExport
{
    class SPXExport
     {
        static void Main(string[] args)
        {
            BusinessManager iBo = new BusinessManager();
            string skipFTP = ConfigurationManager.AppSettings["SkipFTPStep"].ToString();
            
            try
            {
                // this is the thread exception handler
                AppDomain curDomain = AppDomain.CurrentDomain;
                curDomain.UnhandledException += new UnhandledExceptionEventHandler(SPXExport_UnhandledException);
                List<string> lstUploadedFiles = iBo.FileSweeper();
                
                List<ShippingRecord> lstShippingRecords = iBo.ExtractUploadedData(lstUploadedFiles);
                iBo.StageUploadedData(lstShippingRecords);
                List<ShippingRecord> lstValidShippingRecords = iBo.ValidateUploadedData(lstShippingRecords);
                // this is an assumption - valid and invalid will both be returned and flagged
                iBo.CallSageComponent(lstValidShippingRecords);
                
                iBo.MoveFTPFilesToArchive(lstUploadedFiles);

                
            }
            catch (Exception ex)
            {
                // this is to catch any single threaded exceptions
                Console.WriteLine("in Catch block");
                
            }
            finally
            {
                Console.WriteLine("Fin.");
            }
        }

        static void SPXExport_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            // this is to catch any exceptions in threading
            Console.WriteLine("in Unhandled exception block");
        }

       
    }
}
