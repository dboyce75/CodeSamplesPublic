﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SystemFrameworks;

namespace BusinessLayer
{
    interface IBusiness
    {
        List<string> FileSweeper();
        List<ShippingRecord> ExtractUploadedData(List<string> lstUploadedFiles);
        void StageUploadedData(List<ShippingRecord> lstShippingRecords);
        List<ShippingRecord> CallSageComponent(List<ShippingRecord> lstValidShippingRecords);
        List<ShippingRecord> ValidateUploadedData(List<ShippingRecord> lstShippingRecords);
        void MoveFTPFilesToArchive(List<string> lstFilesToArchive);

    }
}
