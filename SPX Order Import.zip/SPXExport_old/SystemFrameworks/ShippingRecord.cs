﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SystemFrameworks
{
    enum DataFieldsEnum
    {
        TrackingID = 0,
        ShipDate = 1
    }

    public class ShippingRecord
    {
        // these may all be header records
        public string TrackingID { get; set; }
        public string ShipDate { get; set; }
        public string ShipCarrier { get; set; }
        public string ShipSvcCode { get; set; }
        public string ActualWeight { get; set; }
        public string Customer { get; set; }
        public string Facility { get; set; }
        public string OrderNumber { get; set; }
        public string ReferenceNumber { get; set; }
        public string PONumber { get; set; }
        public string DepartmentID { get; set; }
        public string ReferenceNumber2 { get; set; }
        public string ShipContact { get; set; }
        public string ShipCompany { get; set; }
        public string ShipAddress1 { get; set; }
        public string ShipAddress2 { get; set; }
        public string ShipCity { get; set; }
        public string ShipState { get; set; }
        public string ShipZip { get; set; }
        public string ShipCountry { get; set; }
        // this may be the detail records
        public string Item { get; set; }
        public string Quantity { get; set; }
        public string UnitOfMeasure { get; set; }
        public string PassThruChar06 { get; set; }
        public string LotNumber { get; set; }
        public string ShipID { get; set; }
        
        // these are not in the feed - might be helpful in the process
        public string SourceFileName { get; set; }
        public string ProcessingStatus { get; set; }
        public string ProcessedDate { get; set; }

        public ShippingRecord(string currLine)
        {
            string[] cells = currLine.Split('|');
            TrackingID = cells[BusinessConstants.TRACKINGNUMBER];
            ShipDate = cells[BusinessConstants.SHIPDATE];
            ShipCarrier = cells[BusinessConstants.SHIPCARRIER];
            ShipSvcCode = cells[BusinessConstants.SHIPSVCCODE];
            ActualWeight = cells[BusinessConstants.ACTUALWEIGHT];
            Customer = cells[BusinessConstants.CUSTOMER];
            Facility = cells[BusinessConstants.FACILITY];
            OrderNumber = cells[BusinessConstants.ORDERNUMBER];
            ReferenceNumber = cells[BusinessConstants.REFERENCENUMBER];
            PONumber = cells[BusinessConstants.PONUMBER];
            DepartmentID = cells[BusinessConstants.DEPARTMENTID];
            ReferenceNumber2 = cells[BusinessConstants.REFERENCENUMBER2];
            ShipContact = cells[BusinessConstants.SHIPCONTACT];
            ShipCompany = cells[BusinessConstants.SHIPCOMPANY];
            ShipAddress1 = cells[BusinessConstants.SHIPADDRESS1];
            ShipAddress2 = cells[BusinessConstants.SHIPADDRESS2];
            ShipCity = cells[BusinessConstants.SHIPCITY];
            ShipState = cells[BusinessConstants.SHIPSTATE];
            ShipZip = cells[BusinessConstants.SHIPZIP];
            ShipCountry = cells[BusinessConstants.SHIPCOUNTRY];
            Item = cells[BusinessConstants.ITEM];
            Quantity = cells[BusinessConstants.QUANTITY];
            UnitOfMeasure = cells[BusinessConstants.UNITOFMEASURE];
            PassThruChar06 = cells[BusinessConstants.HDRPASSTHRUCHAR06];
            LotNumber = cells[BusinessConstants.LOTNUMBER];
            ShipID = cells[BusinessConstants.SHIPID];

            //TRACKINGID|SHIPDATE|SHIPCARRIER|SHIPSRVCODE|ACT_WGT|CUSTOMER|FACILITY|ORDERNBR|REFERENCENBR|PONUMBER|DEPARTMENTID|REFERENCENBR2|SHIPCONTACT|SHIPCOMPANY|
            //SHIPADDRESS1|SHIPADDRESS2|SHIPCITY|SHIPSTATE|SHIPZIP|SHIPCOUNTRY|ITEM|QUANTITY|UNITOFMEASURE|HDRPASSTHRUCHAR06|LOTNUMBER|SHIPID
        }

    }

}
