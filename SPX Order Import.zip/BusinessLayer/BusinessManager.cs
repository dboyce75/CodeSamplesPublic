﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using SystemFrameworks;
using System.Net;
using System.Configuration;
using System.Security.Principal;
using System.Security.Cryptography;
using System.Diagnostics;
using DataLayer;
using Utilities;
using Proxy.ext;

namespace BusinessLayer
{
    public class BusinessManager : IBusiness
    {
        DataManager iDo = new DataManager();

        public List<string> FileSweeper()
        {
            List<string> lstFilesToDownload = new List<string>();
            List<string> lstScrubbedFileNames = new List<string>();
            //FTP - get files and return

            lstFilesToDownload = GetFilesForDownload();

            // this file list returns the folder "ARCHIVE" - we need to remove it from the flow - NOTE - do not ADD more folders under this structure
            foreach (string f in lstFilesToDownload)
            {
                if (f != "ARCHIVE" && f != "TEST")
                {
                    // do lookup to see if the file has already been processed 
                    bool fileAlreadyProcessed = iDo.CheckForDuplicateFile(f);
                    if (!fileAlreadyProcessed) {
                        // somehow the file has been processed, but never got archived
                        lstScrubbedFileNames.Add(f);
                    }
                }
                
            }
            
            int counter = 0;
            counter = DownloadFilesFromFTP(lstScrubbedFileNames);
            return lstScrubbedFileNames;
        }

        public List<ShippingRecord> ExtractUploadedData(string strUploadedFile)
        {
            int counter = 0;
            string line2;
            StreamReader file = null;

            List<ShippingRecord> lstShippingRecords = new List<ShippingRecord>();
            try
            {
                counter = 0;
                file = new StreamReader(ConfigurationManager.AppSettings["InputFilePath"] + strUploadedFile);
                while ((line2 = file.ReadLine()) != null)
                {
                    if (counter != 0) // this skips the first header row.
                    {
                        ShippingRecord sr = new ShippingRecord(line2);
                        sr.SourceFileName = strUploadedFile;
                        lstShippingRecords.Add(sr);
                    }
                    counter++;
                }
                file.Close();
                    // TODO - log that file was successfully imported in DB
            }

            catch (Exception ex)
            {
                throw ex;
            }
            finally 
            {
                if (file != null)
                {
                    file.Close();
                }
            }
            
            return lstShippingRecords;
        }

        public void MoveFileToNetworkShare(string strFileToArchive)
        {
            // this is all that's needed
            try
            {
                File.Copy(ConfigurationManager.AppSettings["InputFilePath"] + strFileToArchive, ConfigurationManager.AppSettings["NetworkSharePath"] + strFileToArchive, true);
                File.Delete(ConfigurationManager.AppSettings["InputFilePath"] + strFileToArchive);
            }
            catch (Exception ex)
            {
                Utils uu = new Utils();
                uu.GenerateCaughtException("Move File To Network Share", ex);
            }
        }

        private int DownloadFilesFromFTP(List<string> lstFilesToDownload)
        {
            string ftpServer = ConfigurationManager.AppSettings["FTPServer"];
            string remoteDirectory = ConfigurationManager.AppSettings["FTPRemoteDirectory"];
            string ftpUserID = ConfigurationManager.AppSettings["FTPUserID"];
            string ftpPassword = Decrypt(ConfigurationManager.AppSettings["FTPPassword"]);
            string inputFilePath = ConfigurationManager.AppSettings["InputFilePath"];

            Stream reader = null;
            FileStream fileStream = null;
            int counter = 0;

            try
            {
                foreach (string file in lstFilesToDownload)
                {
                        int bytesRead = 0;
                        byte[] buffer = new byte[2048];
                        FtpWebRequest reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + ftpServer + "/" + remoteDirectory +"/" + file));
                        reqFTP.UseBinary = true;
                        reqFTP.Credentials = new NetworkCredential(ftpUserID, ftpPassword);
                        reqFTP.Method = WebRequestMethods.Ftp.DownloadFile;
                        reqFTP.Proxy = null;
                        reqFTP.KeepAlive = false;
                        reqFTP.UsePassive = false;

                        reader = reqFTP.GetResponse().GetResponseStream();
                        fileStream = new FileStream(inputFilePath + "/" + file, FileMode.Create);

                        while (true)
                        {
                            bytesRead = reader.Read(buffer, 0, buffer.Length);
                            if (bytesRead == 0)
                                break;
                            fileStream.Write(buffer, 0, bytesRead);
                        }

                        fileStream.Close();
                        counter++;
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (counter > 1)
                {
                    // send email?
                }

                if (reader != null)
                {
                    reader.Close();
                }
                if (fileStream != null)
                {
                    fileStream.Close();
                }
            }
            return counter;
        }
    
        private List<string> GetFilesForDownload()
        {

            StringBuilder result = new StringBuilder();
            WebResponse response = null;
            StreamReader reader = null;
            string ftpServer = ConfigurationManager.AppSettings["FTPServer"];
            string remoteDirectory = ConfigurationManager.AppSettings["FTPRemoteDirectory"];
            string ftpUserID = ConfigurationManager.AppSettings["FTPUserID"];
            string ftpPassword = Decrypt(ConfigurationManager.AppSettings["FTPPassword"]);
            List<string> fileList = new List<string>();

            try
            { // this gets a list of files
                FtpWebRequest reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + ftpServer + "/" + remoteDirectory));
                reqFTP.UseBinary = true;
                reqFTP.Credentials = new NetworkCredential(ftpUserID, ftpPassword);
                reqFTP.Method = WebRequestMethods.Ftp.ListDirectory;
                reqFTP.Proxy = null;
                reqFTP.KeepAlive = false;
                reqFTP.UsePassive = false;
                response = reqFTP.GetResponse();
                reader = new StreamReader(response.GetResponseStream());

                while (!reader.EndOfStream)
                {
                        fileList.Add(reader.ReadLine());
                }
            }
            
            catch (ObjectDisposedException odEx)
            {
                return fileList; // just ignore for now
            }
            catch (Exception ex)
            {
                // TODO - handle this better
                Utils uu = new Utils();
                uu.SendInformationalEmail(ex.Message.ToString(), " FTP Error(s) - SPX");
                fileList = null;
                return fileList;
            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }
                if (response != null)
                {
                    response.Close();
                }
            }
            return fileList;
        }

        public void StageUploadedData(List<ShippingRecord> lstShippingRecords, string fileBeingProcessed)
        {
            try
            {
                // first call the truncate table step
                iDo.TruncateStagingTable();
                // next iterate and add records
                foreach (ShippingRecord sp in lstShippingRecords)
                {
                    iDo.LoadIncomingShippingRecords(sp, fileBeingProcessed);

                }
            }
            catch (Exception ex)
            {

            }
        }

        public List<SageDetail> CallSageComponent(List<SageDetail> lstValidShippingRecords)
        {
            StringBuilder logMessage = new StringBuilder();
            List<SageDetail> postSageShippingRecords = new List<SageDetail>();

            foreach (SageDetail sp in lstValidShippingRecords)
            {
                try
                {
                    // ********* DLL METHOD *************
                    // as parameters:  caction, cornum, ccustno, cbatchno, cinvno, cshipvia, cshipdate
                    Proxy.ext.extinvoice inv = new Proxy.ext.extinvoice();

                    inv.CACTION = "INVOICE";
                    inv.CORNUM = sp.OrderNumber;
                    inv.CCUSTNO = sp.CustomerNumber;
                    
                    if (sp.BatchID != null)
                    {
                        inv.CBATCHNO = sp.BatchID;
                    }
                    else
                    {
                        inv.CBATCHNO = "";
                    }
                    inv.CINVNO = sp.InvoiceNumber; 
                    inv.CSHIPVIA = sp.ShipVia;
                    DateTime dt = DateTime.Parse(sp.ShipDate);
                    inv.CSHIPDATE = dt.ToString("yyyyMMdd");                        
                        
                    //inv.CSHIPDATE = "20150610";
                    
                    string retVal = inv.einv();
                    
                    switch (retVal)
                    {
                        case "SUCCESS":
                            // good!

                            break;
                        case "Record failed to insert into ARTRAN":
                            // do something
                            logMessage.Append("ARTRAN insert failed:  Invoice: " + sp.InvoiceNumber + " Order: " + sp.OrderNumber + " Customer: " + sp.CustomerNumber + Environment.NewLine);
                            
                            break;
                        case "Invoice number not found in ARMAST":
                            // do something else
                            logMessage.Append("AMAST NOT FOUND: File:  Invoice: " + sp.InvoiceNumber + " Order: " + sp.OrderNumber + " Customer: " + sp.CustomerNumber + Environment.NewLine);
                            
                            break;
                        default:
                            logMessage.Append(" Unhandled exception:  Invoice: " + sp.InvoiceNumber + " Order: " + sp.OrderNumber + " Customer: " + sp.CustomerNumber + " Retval = " + retVal + Environment.NewLine);
                            
                            break;
                    }
                    iDo.UpdateTrackingStatus(sp.OrderNumber, retVal);
                    postSageShippingRecords.Add(sp);
                    System.Threading.Thread.Sleep(Convert.ToInt32(ConfigurationManager.AppSettings["SageDLLSleepTimer"].ToString()));

                }
                catch (Exception ex)
                {
                    Utils uu = new Utils();
                    uu.GenerateCaughtException("Call Sage Component", ex);
                }
            }
            if (logMessage.Length != 0)
            {
                // some exception occurred
                Utils uu = new Utils();
                uu.SendInformationalEmail(logMessage.ToString(), "Error(s) in CallSageDLL");

            }
            return postSageShippingRecords;
        }

        public void FinalizeOrders()
        {
            try
            {
                iDo.FinalizeOrders();
            }
            catch (Exception ex)
            {
                Utils uu = new Utils();
                uu.GenerateCaughtException("Finalize Orders", ex);
            }
        }
        public List<SageDetail> ValidateUploadedData()
        {
            List<SageDetail> lstSageDetail = new List<SageDetail>();

            try
            {
                lstSageDetail = iDo.GetScrubbedData();
            }
            catch (Exception ex)
            {
                Utils uu = new Utils();
                uu.GenerateCaughtException("Validate Uploaded Data", ex);
            }
            
            return lstSageDetail;
            
           
        }

        public void MoveFTPFileToArchive(string strFileToArchive)
        {
            string ftpServer = ConfigurationManager.AppSettings["FTPServer"];
            string remoteDirectory = ConfigurationManager.AppSettings["FTPRemoteDirectory"];
            string ftpUserID = ConfigurationManager.AppSettings["FTPUserID"];
            string ftpPassword = Decrypt(ConfigurationManager.AppSettings["FTPPassword"]);
            string outputFilePath = ConfigurationManager.AppSettings["InputFilePath"];
            string archiveDirectory = ConfigurationManager.AppSettings["FTPArchiveDirectory"];

            try
            {
                    FtpWebRequest reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + ftpServer + "/" + remoteDirectory + "/" + strFileToArchive));
                    reqFTP.UseBinary = true;
                    reqFTP.Credentials = new NetworkCredential(ftpUserID, ftpPassword);
                    reqFTP.Method = WebRequestMethods.Ftp.Rename;
                    reqFTP.Proxy = null;
                    reqFTP.KeepAlive = false;
                    reqFTP.UsePassive = false;
                    reqFTP.RenameTo = new Uri("ftp://" + ftpServer + "/" + archiveDirectory + "/" + strFileToArchive).AbsolutePath;
                    reqFTP.GetResponse();
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    
        private static string Decrypt(string cipherText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }

    }
}
