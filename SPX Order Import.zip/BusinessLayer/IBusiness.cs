﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SystemFrameworks;

namespace BusinessLayer
{
    interface IBusiness
    {
        List<string> FileSweeper();
        List<ShippingRecord> ExtractUploadedData(string strUploadedFile);
        void StageUploadedData(List<ShippingRecord> lstShippingRecords, string fileBeingProcessed);
        List<SageDetail> CallSageComponent(List<SageDetail> lstValidShippingRecords);
        List<SageDetail> ValidateUploadedData();
        void FinalizeOrders();
        void MoveFTPFileToArchive(string strFileToArchive);
        void MoveFileToNetworkShare(string strFileToArchive);

    }
}
