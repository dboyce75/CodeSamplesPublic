﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SystemFrameworks
{
    public static class BusinessConstants
    {
        public const int TRACKINGNUMBER = 0;
        public const int SHIPDATE = 1;
        public const int SHIPCARRIER = 2;
        public const int SHIPSVCCODE = 3;
        public const int ACTUALWEIGHT = 4;
        public const int CUSTOMER = 5;
        public const int FACILITY = 6;
        public const int ORDERNUMBER = 7;
        public const int REFERENCENUMBER = 8;
        public const int PONUMBER = 9;
        public const int DEPARTMENTID = 10;
        public const int REFERENCENUMBER2 = 11;
        public const int SHIPCONTACT = 12;
        public const int SHIPCOMPANY = 13;
        public const int SHIPADDRESS1 = 14;
        public const int SHIPADDRESS2= 15;
        public const int SHIPCITY = 16;
        public const int SHIPSTATE = 17;
        public const int SHIPZIP = 18;
        public const int SHIPCOUNTRY = 19;
        public const int ITEM = 20;
        public const int QUANTITY = 21;
        public const int UNITOFMEASURE = 22;
        public const int HDRPASSTHRUCHAR06= 23;
        public const int LOTNUMBER = 24;
        public const int SHIPID = 25;
        public const int DTLPASSTHRUCHAR10=26;
        public const int DTLPASSTHRUCHAR11=27;
        public const int DTLPASSTHRUCHAR08=28;
        //TRACKINGID|SHIPDATE|SHIPCARRIER|SHIPSRVCODE|ACT_WGT|CUSTOMER|FACILITY|ORDERNBR|REFERENCENBR|PONUMBER|DEPARTMENTID|REFERENCENBR2|SHIPCONTACT|SHIPCOMPANY|
        //SHIPADDRESS1|SHIPADDRESS2|SHIPCITY|SHIPSTATE|SHIPZIP|SHIPCOUNTRY|ITEM|QUANTITY|UNITOFMEASURE|HDRPASSTHRUCHAR06|LOTNUMBER|SHIPID|DTLPASSTHRUCHAR10|DTLPASSTHRUCHAR11|DTLPASSTHRUCHAR08
    }
}
