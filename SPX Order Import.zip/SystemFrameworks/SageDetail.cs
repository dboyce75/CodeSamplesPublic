﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SystemFrameworks
{
    public class SageDetail
    {
        public string BatchID { get; set; }
        public string OrderNumber { get; set; }
        public string InvoiceNumber { get; set; }
        public string CustomerNumber { get; set; }
        public string ShipVia { get; set; }
        public string InvoiceDate { get; set; }
        public string ShipDate { get; set; }
        public string TrackingDate { get; set; }

    }
}
