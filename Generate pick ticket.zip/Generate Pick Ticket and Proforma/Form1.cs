﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Web.Services.Protocols;
using System.IO;
using Generate_Pick_Ticket_and_Proforma.ssrs_ws;



namespace Generate_Pick_Ticket_and_Proforma
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Working...";
            // build array or dictionary

            // iterate through array and generate PDFs




            ReportExecutionService rs = new ReportExecutionService();
            rs.Credentials = System.Net.CredentialCache.DefaultCredentials;
            byte[] result = null;
            string reportPath = "/Reports/Warehouse/Accudart/PickTicketAPP/Pick Ticket";
            string format = "PDF";
            string historyID = null;
            string devInfo = @"<DeviceInfo><Toolbar>False</Toolbar></DeviceInfo>";


            ParameterValue[] parameters = new ParameterValue[2];
            parameters[0] = new ParameterValue();
            parameters[0].Name = "OrderNo";
            parameters[0].Value = txtOrderNo.Text;
            parameters[1] = new ParameterValue();
            parameters[1].Name = "ARPickLine";
            parameters[1].Value = txtPickLine.Text; 

            //DataSourceCredentials[] credentials = null;
            //string showHideToggle = null;
            string encoding;
            string mimeType;
            string extension;
            Warning[] warnings = null;
            string[] streamIDs = null;

            ExecutionInfo execInfo = new ExecutionInfo();
            ExecutionHeader execHeader = new ExecutionHeader();

            rs.ExecutionHeaderValue = execHeader;
            
            execInfo = rs.LoadReport(reportPath, historyID);
            rs.SetExecutionParameters(parameters, "en-us"); 
            String SessionId = rs.ExecutionHeaderValue.ExecutionID;
            try
            {
                result = rs.Render(format, devInfo, out extension, out encoding, out mimeType, out warnings, out streamIDs);
                execInfo = rs.GetExecutionInfo();
                //Console.WriteLine("Execution date and time: {0}", execInfo.ExecutionDateTime);
            }
            catch (SoapException ex)
            {
                Console.WriteLine(ex.Detail.OuterXml);
            }
            // Write the contents of the report to a PDF file.
            try
            {
                string fileOutName = System.Configuration.ConfigurationManager.AppSettings["FileOutLocation"].Replace(":\"",":\\");
                fileOutName += "\\PickTicket" + txtOrderNo.Text + ".pdf";
                FileStream stream = File.Create(fileOutName, result.Length);
                toolStripStatusLabel1.Text = "File created.";
                stream.Write(result, 0, result.Length);
                toolStripStatusLabel1.Text = "Pickticket" + txtOrderNo.Text + ".pdf created successfully @ " + System.Configuration.ConfigurationManager.AppSettings["FileOutLocation"];
                stream.Close();
            }
            catch (Exception ex2)
            {
                Console.WriteLine(ex2.Message);
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "Output Location - " + System.Configuration.ConfigurationManager.AppSettings["FileOutLocation"];
        }

        private void button2_Click(object sender, EventArgs e)
        {

            // build array or dictionary of order numbers
            List<string> lstOrderNums = new List<string>();
            lstOrderNums = BuildOrderArray();


            // iterate through the array and output them each to a folder
            toolStripStatusLabel1.Text = "Working...";

            foreach (string strItem in lstOrderNums)
            {

                ReportExecutionService rs = new ReportExecutionService();
                rs.Credentials = System.Net.CredentialCache.DefaultCredentials;
                byte[] result = null;
                string reportPath = "/Reports/Warehouse/Accudart/PickTicketAPP/Proforma Invoice";
                string format = "PDF";
                string historyID = null;
                string devInfo = @"<DeviceInfo><Toolbar>False</Toolbar></DeviceInfo>";


                ParameterValue[] parameters = new ParameterValue[1];
                parameters[0] = new ParameterValue();
                parameters[0].Name = "OrderNo";
                parameters[0].Value = strItem;

                string encoding;
                string mimeType;
                string extension;
                Warning[] warnings = null;
                string[] streamIDs = null;

                ExecutionInfo execInfo = new ExecutionInfo();
                ExecutionHeader execHeader = new ExecutionHeader();

                rs.ExecutionHeaderValue = execHeader;
                execInfo = rs.LoadReport(reportPath, historyID);
                rs.SetExecutionParameters(parameters, "en-us");
                String SessionId = rs.ExecutionHeaderValue.ExecutionID;
                //Console.WriteLine("SessionID: {0}", rs.ExecutionHeaderValue.ExecutionID);
                try
                {
                    result = rs.Render(format, devInfo, out extension, out encoding, out mimeType, out warnings, out streamIDs);
                    execInfo = rs.GetExecutionInfo();
                    //Console.WriteLine("Execution date and time: {0}", execInfo.ExecutionDateTime);
                }
                catch (SoapException ex)
                {
                    Console.WriteLine(ex.Detail.OuterXml);
                }
                // Write the contents of the report to an PDF file.
                try
                {
                    string fileOutName = System.Configuration.ConfigurationManager.AppSettings["FileOutLocation"].Replace(":\"", ":\\");
                    fileOutName += "\\ProformaInvoice" + strItem + ".PDF";
                    FileStream stream = File.Create(fileOutName, result.Length);
                    toolStripStatusLabel1.Text = "File created.";
                    stream.Write(result, 0, result.Length);
                    //toolStripStatusLabel1.Text = "ProformaInvoice" + txtInvoiceOrderNo.Text + ".pdf created successfully @ " + System.Configuration.ConfigurationManager.AppSettings["FileOutLocation"];
                    stream.Close();
                }
                catch (Exception ex2)
                {
                    Console.WriteLine(ex2.Message);
                }
            }
        }

        private List<string> BuildOrderArray()
        {
            List<string> lst = new List<string>();
            lst.Add("11450300");
            lst.Add("11450269");
            lst.Add("11450233");
            lst.Add("11450231");
            lst.Add("11450229");
            lst.Add("11450228");
            lst.Add("11448806");
            lst.Add("11448796");
            lst.Add("11448794");
            lst.Add("11448785");
            lst.Add("11450381");
            lst.Add("11449162");
            lst.Add("11449152");
            lst.Add("11449131");
            lst.Add("11449089");
            lst.Add("11448944");
            lst.Add("11448918");
            lst.Add("11448898");
            lst.Add("11448863");
            lst.Add("11448854");
            lst.Add("11448648");
            lst.Add("11448631");
            lst.Add("11448622");
            lst.Add("11448510");
            lst.Add("11447023");
            lst.Add("11447011");
            lst.Add("11444336");
            lst.Add("11443597");
            lst.Add("11443012");
            lst.Add("11450304");
            lst.Add("11450286");
            lst.Add("11450250");
            lst.Add("11450234");
            lst.Add("11449578");
            lst.Add("11450251");
            lst.Add("11445644");
            lst.Add("11450242");
            lst.Add("11443376");
            lst.Add("11441930");
            lst.Add("11439577");
            lst.Add("11435993");
            lst.Add("11440920");
            lst.Add("11450227");
            lst.Add("11450226");
            lst.Add("11450215");
            lst.Add("11450205");
            lst.Add("11450015");
            lst.Add("11449820");
            lst.Add("11438693");
            lst.Add("11450181");
            lst.Add("11450180");
            lst.Add("11450178");
            lst.Add("11450177");
            lst.Add("11450174");
            lst.Add("11450171");
            lst.Add("11450170");
            lst.Add("11450168");
            lst.Add("11450199");
            lst.Add("11450166");
            lst.Add("11450198");
            lst.Add("11450164");
            lst.Add("11450151");
            lst.Add("11450162");
            lst.Add("11449963");
            lst.Add("11450161");
            lst.Add("11449900");
            lst.Add("11450158");
            lst.Add("11450157");
            lst.Add("11450156");
            lst.Add("11450155");
            lst.Add("11450153");
            lst.Add("11450152");
            lst.Add("11450147");
            lst.Add("11450146");
            lst.Add("11450144");
            lst.Add("11450142");
            lst.Add("11450141");
            lst.Add("11450140");
            lst.Add("11450138");
            lst.Add("11450135");
            lst.Add("11450133");
            lst.Add("11450131");
            lst.Add("11450129");
            lst.Add("11450128");
            lst.Add("11450125");
            lst.Add("11450124");
            lst.Add("11450121");
            lst.Add("11450120");
            lst.Add("11450189");
            lst.Add("11450165");
            lst.Add("11450160");
            lst.Add("11450148");
            lst.Add("11450143");
            lst.Add("11450139");
            lst.Add("11450134");
            lst.Add("11450130");
            lst.Add("11450123");
            lst.Add("11450119");
            lst.Add("11450103");
            lst.Add("11450095");
            lst.Add("11450045");
            lst.Add("11449958");
            lst.Add("11449954");
            lst.Add("11449953");
            lst.Add("11449951");
            lst.Add("11449905");
            lst.Add("11449904");
            lst.Add("11449902");
            lst.Add("11449697");
            lst.Add("11446730");
            lst.Add("11450175");
            lst.Add("11450089");
            lst.Add("11450116");
            lst.Add("11450115");
            lst.Add("11450114");
            lst.Add("11450113");
            lst.Add("11450104");
            lst.Add("11450074");
            lst.Add("11450073");
            lst.Add("11450063");
            lst.Add("11450048");
            lst.Add("11450047");
            lst.Add("11450044");
            lst.Add("11450041");
            lst.Add("11450040");
            lst.Add("11450030");
            lst.Add("11450028");
            lst.Add("11450027");
            lst.Add("11450026");
            lst.Add("11450007");
            lst.Add("11449990");
            lst.Add("11449981");
            lst.Add("11449979");
            lst.Add("11449975");
            lst.Add("11449974");
            lst.Add("11449971");
            lst.Add("11449965");
            lst.Add("11450016");
            lst.Add("11450088");
            lst.Add("11450087");
            lst.Add("11450086");
            lst.Add("11450084");
            lst.Add("11450082");
            lst.Add("11450081");
            lst.Add("11450080");
            lst.Add("11450078");
            lst.Add("11450071");
            lst.Add("11450066");
            lst.Add("11450065");
            lst.Add("11450039");
            lst.Add("11450037");
            lst.Add("11450042");
            lst.Add("11450033");
            lst.Add("11450023");
            lst.Add("11450020");
            lst.Add("11450018");
            lst.Add("11449999");
            lst.Add("11449993");
            lst.Add("11449989");
            lst.Add("11449987");
            lst.Add("11449986");
            lst.Add("11449985");
            lst.Add("11450092");
            lst.Add("11449997");
            lst.Add("11449962");
            lst.Add("11449959");
            lst.Add("11449956");
            lst.Add("11449955");
            lst.Add("11449952");
            lst.Add("11449949");
            lst.Add("11449903");
            lst.Add("11449894");
            lst.Add("11449892");
            lst.Add("11449886");
            lst.Add("11449885");
            lst.Add("11449884");
            lst.Add("11449869");
            lst.Add("11449826");
            lst.Add("11448482");
            lst.Add("11448022");
            lst.Add("11443854");
            lst.Add("11450069");
            lst.Add("11450061");
            lst.Add("11450059");
            lst.Add("11450057");
            lst.Add("11450055");
            lst.Add("11449972");
            lst.Add("11449967");
            lst.Add("11449883");
            lst.Add("11449877");
            lst.Add("11449876");
            lst.Add("11449863");
            lst.Add("11449862");
            lst.Add("11449858");
            lst.Add("11449854");
            lst.Add("11449853");
            lst.Add("11449852");
            lst.Add("11449851");
            lst.Add("11449850");
            lst.Add("11449848");
            lst.Add("11449847");
            lst.Add("11450004");
            lst.Add("11449754");
            lst.Add("11449846");
            lst.Add("11449844");
            lst.Add("11449843");
            lst.Add("11449836");
            lst.Add("11449829");
            lst.Add("11449825");
            lst.Add("11449819");
            lst.Add("11449803");
            lst.Add("11449799");
            lst.Add("11449769");
            lst.Add("11449768");
            lst.Add("11449756");
            lst.Add("11449746");
            lst.Add("11449678");
            lst.Add("11449556");
            lst.Add("11444796");
            lst.Add("11440935");
            lst.Add("11437543");
            lst.Add("11449948");
            lst.Add("11449812");
            lst.Add("11449802");
            lst.Add("11449796");
            lst.Add("11449795");
            lst.Add("11449789");
            lst.Add("11449786");
            lst.Add("11449783");
            lst.Add("11449780");
            lst.Add("11449774");
            lst.Add("11449770");
            lst.Add("11449743");
            lst.Add("11449740");
            lst.Add("11449731");
            lst.Add("11449729");
            lst.Add("11449724");
            lst.Add("11449723");
            lst.Add("11449721");
            lst.Add("11449713");
            lst.Add("11449707");
            lst.Add("11449702");
            lst.Add("11449666");
            lst.Add("11449661");
            lst.Add("11449643");
            lst.Add("11449052");
            lst.Add("11448947");
            lst.Add("11446865");
            lst.Add("11440382");
            lst.Add("11449709");
            lst.Add("11449439");
            lst.Add("11449728");
            lst.Add("11449705");
            lst.Add("11449572");
            lst.Add("11444607");
            lst.Add("11448767");
            lst.Add("11443358");
            lst.Add("11443356");
            lst.Add("11443355");
            lst.Add("11443335");
            lst.Add("11443297");
            lst.Add("11443294");
            lst.Add("11443293");
            lst.Add("11443292");
            lst.Add("11443291");
            lst.Add("11443288");
            lst.Add("11443287");
            lst.Add("11443284");
            lst.Add("11443283");
            lst.Add("11449868");
            lst.Add("11443281");
            lst.Add("11449866");
            lst.Add("11443278");
            lst.Add("11443276");
            lst.Add("11443272");
            lst.Add("11443271");
            lst.Add("11443268");
            lst.Add("11443266");
            lst.Add("11443263");
            lst.Add("11443261");
            lst.Add("11443259");
            lst.Add("11443258");
            lst.Add("11443256");
            lst.Add("11443254");
            lst.Add("11443251");
            lst.Add("11443250");
            lst.Add("11443249");
            lst.Add("11443248");
            lst.Add("11443242");
            lst.Add("11443239");
            lst.Add("11443238");
            lst.Add("11443237");
            lst.Add("11443236");
            lst.Add("11443232");
            lst.Add("11443229");
            lst.Add("11443228");
            lst.Add("11443227");
            lst.Add("11443226");
            lst.Add("11443225");
            lst.Add("11443219");
            lst.Add("11443214");
            lst.Add("11443213");
            lst.Add("11443152");
            lst.Add("11443146");
            lst.Add("11443137");
            lst.Add("11443134");
            lst.Add("11443131");
            lst.Add("11443121");
            lst.Add("11443120");
            lst.Add("11443118");
            lst.Add("11443111");
            lst.Add("11443110");
            lst.Add("11443105");
            lst.Add("11443097");
            lst.Add("11443076");
            lst.Add("11443002");
            lst.Add("11442982");
            lst.Add("11442975");
            lst.Add("11442972");
            lst.Add("11442971");
            lst.Add("11448825");
            lst.Add("11449888");
            lst.Add("11446711");
            lst.Add("11448658");
            lst.Add("11449867");
            lst.Add("11448594");
            lst.Add("11449782");
            lst.Add("11449764");
            lst.Add("11449732");
            lst.Add("11449658");
            lst.Add("11446735");
            lst.Add("11449748");
            lst.Add("11449722");
            lst.Add("11449720");
            lst.Add("11449719");
            lst.Add("11449698");
            lst.Add("11449693");
            lst.Add("11449576");
            lst.Add("11449571");
            lst.Add("11449567");
            lst.Add("11449563");
            lst.Add("11449562");
            lst.Add("11449517");
            lst.Add("11449235");
            lst.Add("11449219");
            lst.Add("11449205");
            lst.Add("11448667");
            lst.Add("11449502");
            lst.Add("11449497");
            lst.Add("11449632");
            lst.Add("11449663");
            lst.Add("11449494");
            lst.Add("11449492");
            lst.Add("11449491");
            lst.Add("11449490");
            lst.Add("11449489");
            lst.Add("11446877");
            lst.Add("11446745");
            lst.Add("11439885");
            lst.Add("11449395");
            lst.Add("11449329");
            lst.Add("11449328");
            lst.Add("11449327");
            lst.Add("11449326");
            lst.Add("11449324");
            lst.Add("11449323");
            lst.Add("11449322");
            lst.Add("11449107");
            lst.Add("11449106");
            lst.Add("11449105");
            lst.Add("11449104");
            lst.Add("11449103");
            lst.Add("11449102");
            lst.Add("11448969");
            lst.Add("11448828");
            lst.Add("11448581");
            lst.Add("11448578");
            lst.Add("11448575");
            lst.Add("11448572");
            lst.Add("11448580");
            lst.Add("11448574");

            return lst;
        }

    }
}
