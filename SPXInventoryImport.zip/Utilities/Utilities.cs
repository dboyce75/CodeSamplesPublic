﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;
using System.Net;
using System.Configuration;

namespace Utilities
{
    public class Utils
    {
        public void GenerateCaughtException(string callingMethod, Exception ex)
        {
            // Logging ?
            MailMessage msg = null;
            try
            {
                msg = new MailMessage();
                string msgTo = ConfigurationManager.AppSettings["EmailTo"];
                foreach (var emailto in msgTo.Split(new[] { ";" }, StringSplitOptions.RemoveEmptyEntries))
                {
                    msg.To.Add(emailto);
                }
                StringBuilder message = new StringBuilder();
                message.Append("An Exception occured in the SPX Inventory Import" + Environment.NewLine);
                message.Append(callingMethod + Environment.NewLine);
                message.Append(ex.Message + Environment.NewLine);
                message.Append(ex.StackTrace);
                msg.Body = message.ToString();
                msg.IsBodyHtml = false;
                msg.Subject = "Unhandled non threaded exception occurred " + ConfigurationManager.AppSettings["Environment"];
                msg.From = new MailAddress(ConfigurationManager.AppSettings["EmailFrom"]);


                SmtpClient client = new SmtpClient("192.168.20.20", 25);

                using (client)
                {
                    try
                    {
                        client.Send(msg);
                    }

                    catch (Exception exc) { }

                }
            }
            finally { msg.Dispose(); }
        }


        public void GenerateUnhandledException()
        {

        }

        public void SendInformationalEmail(string logMessage, string strSubject)
        {
            MailMessage msg = null;
            try
            {
                msg = new MailMessage();
                string msgTo = ConfigurationManager.AppSettings["EmailTo"];
                foreach (var emailto in msgTo.Split(new[] { ";" }, StringSplitOptions.RemoveEmptyEntries))
                {
                    msg.To.Add(emailto);
                }
                StringBuilder message = new StringBuilder();
                message.Append(strSubject + Environment.NewLine);
                message.Append(logMessage + Environment.NewLine);
                msg.Body = message.ToString();
                msg.IsBodyHtml = false;
                msg.Subject = strSubject + ConfigurationManager.AppSettings["Environment"];
                msg.From = new MailAddress(ConfigurationManager.AppSettings["EmailFrom"]);


                SmtpClient client = new SmtpClient("192.168.20.20", 25);

                using (client)
                {
                    try
                    {
                        client.Send(msg);
                    }

                    catch (Exception exc) { }

                }
            }
            finally { msg.Dispose(); }
        }
    }
}
