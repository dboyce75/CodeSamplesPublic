﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SystemFrameworks;

namespace DataLayer
{
    interface IData
    {
        void TruncateStagingTable();
        void InsertInventoryRecord(SPXInventory spi, string fileName);

    }
}
