﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SystemFrameworks;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Data;
using System.Configuration;
using Utilities;


namespace DataLayer
{
    public class DataManager : IData
    {
        public void InsertInventoryRecord(SPXInventory spi, string fileName)
        {
            SqlCommand cmd = null;
            SqlConnection connx = null;
            try
            {
                using (connx = getConnection())
                {
                    using (cmd = getCommand("InsertRow"))
                    {
                        cmd.Parameters.Add("@FileName", SqlDbType.VarChar).Value = fileName;
                        cmd.Parameters.Add("@ItemNo", SqlDbType.VarChar).Value = spi.ItemNo;
                        cmd.Parameters.Add("@LotNumber", SqlDbType.VarChar).Value = spi.LotNumber;
                        cmd.Parameters.Add("@Quantity", SqlDbType.VarChar).Value = spi.Quantity;
                        cmd.Parameters.Add("@UnitOfMeasure", SqlDbType.VarChar).Value = spi.UnitOfMeasure;
                        cmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = spi.Description;
                        cmd.Parameters.Add("@InventoryClass", SqlDbType.VarChar).Value = spi.InventoryClass;
                        cmd.Parameters.Add("@InventoryStatus", SqlDbType.VarChar).Value = spi.InventoryStatus;
                        
                        cmd.Connection = connx;
                        cmd.CommandType = CommandType.StoredProcedure;
                        connx.Open();

                        int retVal = Convert.ToInt32(cmd.ExecuteNonQuery());
                    }
                }
            }
            catch (Exception ex)
            {
                Utils uu = new Utils();
                uu.GenerateCaughtException("Data Layer - Load Incoming Records ", ex);
                throw ex;
            }
        }





        public void TruncateStagingTable()
        {
            SqlCommand cmd = null;
            SqlConnection connx = null;
            try
            {
                using (connx = getConnection())
                {
                    using (cmd = getCommand("NewFile"))
                    {
                        cmd.Connection = connx;
                        cmd.CommandType = CommandType.StoredProcedure;
                        connx.Open();

                        string retVal = cmd.ExecuteNonQuery().ToString();
                        Console.WriteLine(retVal + " rows deleted in truncate step");
                    }
                }

            }
            catch (Exception ex)
            {
                Utils uu = new Utils();
                uu.GenerateCaughtException("Data Layer - Truncate Staging Table ", ex);
            }
        }

        private SqlConnection getConnection()
        {
            string cxString = ConfigurationManager.ConnectionStrings["DWConnx"].ConnectionString;
            SqlConnection connx = new SqlConnection(cxString);
            return connx;
        }

        private SqlCommand getCommand(string sectionName)
        {
            SqlCommand cmd = new SqlCommand("Dataload.SPXInventoryImportInsert");
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@Section", SqlDbType.VarChar).Value = sectionName;
            return cmd;

        }
    }
}
