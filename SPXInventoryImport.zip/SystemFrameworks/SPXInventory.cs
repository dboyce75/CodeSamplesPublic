﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SystemFrameworks
{
    public class SPXInventory
    {

        public string ItemNo { get; set; }
        public string LotNumber { get; set; }
        public string Quantity { get; set; }
        public string UnitOfMeasure { get; set; }
        public string Description { get; set; }
        public string InventoryClass { get; set; }
        public string InventoryStatus { get; set; }
        public string FileName { get; set; }

        // constructor that maps fields
        public SPXInventory(string currLine)
        {
            string[] cells = currLine.Split('|');
            // cell 0 = LA2 constant
            ItemNo = cells[1];
            // cell 2 = RL constant
            LotNumber = cells[3];
            Quantity = cells[4];
            UnitOfMeasure = cells[5];
            Description = cells[6];
            InventoryClass = cells[7];
            InventoryStatus = cells[8];

        }
        
    }
}
