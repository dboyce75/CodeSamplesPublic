﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Configuration;
using System.Security.Principal;
using System.Security.Cryptography;
using SystemFrameworks;
using DataLayer;
using System.Net;


namespace SPXInventoryImport
{
    class SPXInventoryImport
    {
        static void Main(string[] args)
        {
            DataManager iDM = new DataManager();
            try
            {
                AppDomain curDomain = AppDomain.CurrentDomain;
                curDomain.UnhandledException += new UnhandledExceptionEventHandler(SPXInventoryImport_UnhandledException);
                List<FTPFileSystem> yesterdaysFiles = new List<FTPFileSystem>();
                yesterdaysFiles = GetYesterdaysFiles();
                // get yesterday's file from FTP to local
                DownloadFileFromFTP(yesterdaysFiles[0].Name);
                // extract data 
                string inputFilePath = ConfigurationManager.AppSettings["InputFilePath"];
                string fileName = inputFilePath + yesterdaysFiles[0].Name;
                List<SPXInventory> lstInvRecs = new List<SPXInventory>();
                lstInvRecs = ExtractInventoryData(fileName);
                iDM.TruncateStagingTable();
                foreach (SPXInventory spi in lstInvRecs)
                {
                    iDM.InsertInventoryRecord(spi, fileName);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                
                Console.WriteLine("End...");
            }
        }

        private static void DownloadFileFromFTP(string fileName)
        {
            string ftpServer = ConfigurationManager.AppSettings["FTPServer"];
            string remoteDirectory = ConfigurationManager.AppSettings["FTPRemoteDirectory"];
            string ftpUserID = ConfigurationManager.AppSettings["FTPUserID"];
            string ftpPassword = Decrypt(ConfigurationManager.AppSettings["FTPPassword"]);
            string inputFilePath = ConfigurationManager.AppSettings["InputFilePath"];

            Stream reader = null;
            FileStream fileStream = null;
            int counter = 0;

             try
            {
                int bytesRead = 0;
                byte[] buffer = new byte[2048];
                FtpWebRequest reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + ftpServer + "/" + remoteDirectory + "/" + fileName));
                reqFTP.UseBinary = true;
                reqFTP.Credentials = new NetworkCredential(ftpUserID, ftpPassword);
                reqFTP.Method = WebRequestMethods.Ftp.DownloadFile;
                reqFTP.Proxy = null;
                reqFTP.KeepAlive = false;
                reqFTP.UsePassive = false;

                reader = reqFTP.GetResponse().GetResponseStream();
                fileStream = new FileStream(inputFilePath + fileName, FileMode.Create);

                while (true)
                {
                    bytesRead = reader.Read(buffer, 0, buffer.Length);
                    if (bytesRead == 0)
                        break;
                    fileStream.Write(buffer, 0, bytesRead);
                }

                fileStream.Close();
                counter++;
            }
             catch (Exception ex)
             {
                 throw ex;
             }
             finally
             {
                 if (counter > 1)
                 {
                     // send email?
                 }

                 if (reader != null)
                 {
                     reader.Close();
                 }
                 if (fileStream != null)
                 {
                     fileStream.Close();
                 }
             }
        }

        static void SPXInventoryImport_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            // this is to catch any exceptions in threading
            Console.WriteLine("in Unhandled exception block");
        }

        private static List<FTPFileSystem> GetYesterdaysFiles()
        {
             StreamReader reader = null;
            FtpWebResponse response = null;
            try
            {

                string ftpServer = ConfigurationManager.AppSettings["FTPServer"];
                string remoteDirectory = ConfigurationManager.AppSettings["FTPRemoteDirectory"];
                string ftpUserID = ConfigurationManager.AppSettings["FTPUserID"];
                string ftpPassword = Decrypt(ConfigurationManager.AppSettings["FTPPassword"]);
                string inputFilePath = ConfigurationManager.AppSettings["InputFilePath"];

                //StreamReader reader = null;
                FileStream fileStream = null;
                int counter = 0;
                //FtpWebResponse response = null;

                FtpWebRequest reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + ftpServer + "/" + remoteDirectory));
                reqFTP.UseBinary = true;
                reqFTP.Credentials = new NetworkCredential(ftpUserID, ftpPassword);
                reqFTP.Method = WebRequestMethods.Ftp.ListDirectoryDetails;

                response = reqFTP.GetResponse() as FtpWebResponse;

                Stream responseStream = null;
                responseStream = response.GetResponseStream();
                reader = new StreamReader(responseStream);

                List<FTPFileSystem> subDirs = new List<FTPFileSystem>();

                string subDir = reader.ReadLine();
                FTPFileSystem wrkDir;
                // Find out the FTP Directory Listing Style from the recordString. 
                FTPDirectoryListingStyle style = FTPDirectoryListingStyle.MSDOS;
                if (!string.IsNullOrEmpty(subDir))
                {
                    style = FTPFileSystem.GetDirectoryListingStyle(subDir);
                }
                while (!string.IsNullOrEmpty(subDir))
                {
                    wrkDir = FTPFileSystem.ParseRecordString(new Uri("ftp://" + ftpServer + "/" + remoteDirectory), subDir, style);
                    if (wrkDir.ModifiedTime.DayOfYear == DateTime.Now.AddDays(-1).DayOfYear
                        && wrkDir.ModifiedTime.Year == DateTime.Now.AddDays(-1).Year
                        && wrkDir.IsDirectory == false)
                    {
                        subDirs.Add(FTPFileSystem.ParseRecordString(new Uri("ftp://" + ftpServer + "/" + remoteDirectory), subDir, style));
                    }

                    subDir = reader.ReadLine();
                }

                return subDirs;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (response != null)
                {
                    response.Close();
                }

                // Close the StreamReader object and the underlying stream, and release 
                // any system resources associated with the reader. 
                if (reader != null)
                {
                    reader.Close();
                } 
            }
    }

       


        private static List<SPXInventory> ExtractInventoryData(string fileName)
        {
            int counter = 0;
            string line2;
            StreamReader file = null;

            List<SPXInventory> lstInvRecs = new List<SPXInventory>();
            try
            {
                counter = 0;
                file = new StreamReader(fileName);
                while ((line2 = file.ReadLine()) != null)
                {
                    if (counter != 0) // this skips the first header row.
                    {
                        if (!line2.Contains("DATALOGGER")) // skips last row
                        {
                            SPXInventory sr = new SPXInventory(line2);
                            sr.FileName = fileName;
                            // skip 0 and negative QTY
                            if (Convert.ToInt32(sr.Quantity) != 0)
                            {
                                if (sr.InventoryStatus !="CM")
                                { 
                                    lstInvRecs.Add(sr);
                                }
                            }
                        }

                    }
                    counter++;
                }
                file.Close();
                // TODO - log that file was successfully imported in DB
            }

            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (file != null)
                {
                    file.Close();
                }
            }
            return lstInvRecs;
        }

        private static string Decrypt(string cipherText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }
    }
}
