﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPXInventoryImport
{
    public enum FTPDirectoryListingStyle
    {
        MSDOS = 0,
        UNIX = 1
    } 
}
