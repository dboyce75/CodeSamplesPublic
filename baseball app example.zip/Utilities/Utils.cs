﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using Serilog;


namespace Utilities
{
    public class Utils
    {
        public enum PlayerSearchStatus
        {
            All,
            FA,
            Team
        }

        public void LogSqlException(string logPath, SqlException ex)
        {
            Log.Logger = new LoggerConfiguration()
               .MinimumLevel.Debug()
               // if we want to roll our logs, this is the way
               //.WriteTo.File("C:/Logs/BaseballLog.txt", rollingInterval: RollingInterval.Day, shared: true)
               .WriteTo.File(logPath, shared: true)
               .CreateLogger();

            Log.Error(ex, "SQL Exception");
        }

        public void LogDivideByZeroException(string logPath, DivideByZeroException ex)
        {
            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Debug()
                .WriteTo.File(logPath, shared: true)
                .CreateLogger();

            Log.Error(ex, "Division by 0");
        }

        public void LogException(string logPath, Exception ex)
        {
            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Debug()
                .WriteTo.File(logPath, shared: true)
                .CreateLogger();

            Log.Error(ex, "Unhandled Exception, check stack trace");
        }

        public SqlConnection GetConnection()
        {
            string cxString = ConfigurationManager.ConnectionStrings["BB"].ConnectionString.ToString();
            SqlConnection connx = new SqlConnection(cxString);
            return connx;
        }

        public SqlCommand GetCommand(string uspName)
        {
            SqlCommand cmd = new SqlCommand(uspName);
            cmd.CommandType = CommandType.StoredProcedure;
            // if we use 1 stored proc per system, this will be too complex
            // cmd.Parameters.Add("@Section", SqlDbType.VarChar).Value = sectionName;
            return cmd;

        }



    }
}
