﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using Model;
using Controller;
using Utilities;
using Serilog;
using System.IO;
using System.Configuration;



namespace Fantasy_Baseball_League
{
    public partial class Main : Form
    {
        readonly iLeagueController _leagueController;
        readonly iTeamController _teamController;
        readonly iUtilController _utilController;
        public Main()
        {
            InitializeComponent();
            _leagueController = new LeagueController();
            _teamController = new TeamController();
            _utilController = new UtilController();

            List<PlayerFilter> pfl = new();
            pfl = _utilController.LoadPlayerFilterDD();

            cboPlayerFilter.DataSource = pfl;
            cboPlayerFilter.DisplayMember = "filterDesc";
            cboPlayerFilter.ValueMember = "enumValue";

            ReadCurrentLogFile();

        }

        public Main(iLeagueController leagueController, iTeamController teamController, iUtilController utilController)
        {
            _leagueController = leagueController;
            _teamController = teamController;
            _utilController = utilController;
        }

        private void btnGetAllLeagues_Click(object sender, EventArgs e)
        {
            //Controller.Controller ctrl = new Controller.Controller(); changed to interface
            //iController iControl = new Controller.Controller(); //changed to looser coupling

            List<League> lstLeagues;
            lstLeagues = _leagueController.GetAllLeagues();

            lbLeagues.DataSource = lstLeagues;
            lbLeagues.DisplayMember = "LeagueName";
            lbLeagues.ValueMember = "LeagueID";
        }


        private void lbLeagues_SelectedIndexChanged(object sender, EventArgs e)
        {
            // see which value was selected
            //iController iControl = new Controller.Controller(); //changed to looser coupling

            League tmpLeague = (League)lbLeagues.SelectedItem;
            //League currentLeague;
            List<Team> currentTeams;

            //currentLeague = _leagueController.GetOneLeague(Convert.ToInt32(tmpLeague.LeagueID));
            currentTeams = _leagueController.GetAllTeamsForLeague(Convert.ToInt32(tmpLeague.LeagueID));

            lbTeams.DataSource = currentTeams;
            lbTeams.DisplayMember = "TeamName";
            lbTeams.ValueMember = "TeamID";

            label1.Text = "";

            foreach (Team tm in currentTeams)
            {
                label1.Text = label1.Text + tm.TeamName.ToString() + "  ";
                label1.Text = label1.Text + tm.TeamWins.ToString() + " - ";
                label1.Text = label1.Text + tm.TeamLosses.ToString() + " - ";
                label1.Text = label1.Text + tm.TeamTies.ToString() + Environment.NewLine;
            }
        }

        private void lbTeams_SelectedIndexChanged(object sender, EventArgs e)
        {
            Team tmpTeam = (Team)lbTeams.SelectedItem;

            List<Player> currentPlayers;

            currentPlayers = _teamController.GetAllPlayersForTeam(Convert.ToInt32(tmpTeam.TeamID));

            //lbTeams.DataSource = currentPlayers;
            //lbTeams.DisplayMember = "PlayerName";
            //lbTeams.ValueMember = "PlayerID";

            label1.Text = "";

            foreach (Player ply in currentPlayers)
            {
                label1.Text = label1.Text + ply.PlayerName.ToString() + "  ";
                label1.Text = label1.Text + ply.PlayerTeam.ToString() + "  ";
                label1.Text = label1.Text + Environment.NewLine;
            }
        }

        private void btnGetPlayers_Click(object sender, EventArgs e)
        {

            List<Player> currentPlayers = new List<Player>();
            //Utils.PlayerFilter p = (Utils.PlayerFilter)cboPlayerFilter.SelectedItem;

            int playerFilterSwitch = Convert.ToInt32(cboPlayerFilter.SelectedValue);

            switch (playerFilterSwitch)
            {
                case -1:
                    MessageBox.Show("Please Select a Get Player Filter Option...", "Invalid Player Filter Selection");
                    break;
                case 0:
                    currentPlayers = _teamController.GetAllPlayers(Convert.ToInt32(Utils.PlayerSearchStatus.All));
                    break;
                case 1:
                    currentPlayers = _teamController.GetAllPlayers(Convert.ToInt32(Utils.PlayerSearchStatus.FA), 0, 1);
                    break;
                case 2:
                    currentPlayers = _teamController.GetAllPlayers(Convert.ToInt32(Utils.PlayerSearchStatus.Team), 1);
                    break;
                default:
                    break;
            }

            lbPlayers.DataSource = currentPlayers;
            lbPlayers.DisplayMember = "PlayerName";
            lbPlayers.ValueMember = "PlayerID";

        }

        private void cboPlayerFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            //use SelectionChangeCommitted instead

        }

        private void cboPlayerFilter_SelectionChangeCommitted(object sender, EventArgs e)
        {
            PlayerFilter pf = new();
            pf = (PlayerFilter)cboPlayerFilter.SelectedItem;
            if (pf.EnumValue == -1)
            {
                MessageBox.Show("Please Select a Get Player Filter Option...", "Invalid Player Filter Selection");
            }
            else
            {
                //MessageBox.Show(cboPlayerFilter.SelectedValue.ToString() + " " + pf.filterDesc, "Alert....");
                //implement this later if needed, not sure because button drives the overload invoked
            }
        }


        private void btnTestLogging_Click(object sender, EventArgs e)
        {
            Utils uu = new();
            // divide by 0
            int a = 1, b = 0;
            try
            {
                Log.Debug("Attempt to divide by 0");
                int c = a / b;

            }
            catch (DivideByZeroException ex)
            {
                uu.LogDivideByZeroException(ConfigurationManager.AppSettings["LogPath"], ex);
                
            }
            catch (Exception ex)
            {
                uu.LogException(ConfigurationManager.AppSettings["LogPath"], ex);
            }
            finally
            {
                Log.CloseAndFlush();
                ReadCurrentLogFile();
            }
        }

        private void ReadCurrentLogFile()
        {
            txtBaseballLog.Text = "";
            try
            {
                FileStream filestream = new FileStream("C:/Logs/BaseballLog.txt", FileMode.Open);
                using (StreamReader reader = new StreamReader(filestream))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        txtBaseballLog.Text += line + Environment.NewLine;
                    }
                    filestream.Close();
                    filestream.Dispose();
                }
            }
            catch (FileNotFoundException)
            {
                using (StreamWriter file = new StreamWriter(File.Create("C:/Logs/BaseballLog.txt")))
                {
                    file.WriteLine("Creating Log.....");
                    file.Close();
                    file.Dispose();
                }
            }
            finally
            {
                // not sure if we need to do anything here...
            }
        }

        private void btnClearLog_click(object sender, EventArgs e)
        {
            // TODO

        }

        private void btnTestAppSetting_Click(object sender, EventArgs e)
        {
            string filePath = ConfigurationManager.AppSettings["LogPath"];
            label1.Text = "";
            label1.Text = filePath;
        }
    }
}
