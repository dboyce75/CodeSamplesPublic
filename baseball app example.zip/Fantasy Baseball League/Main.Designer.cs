﻿namespace Fantasy_Baseball_League
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new System.Windows.Forms.Label();
            btnGetAllLeagues = new System.Windows.Forms.Button();
            lbLeagues = new System.Windows.Forms.ListBox();
            lbTeams = new System.Windows.Forms.ListBox();
            listBox2 = new System.Windows.Forms.ListBox();
            cboLeagues = new System.Windows.Forms.ComboBox();
            btnGetPlayers = new System.Windows.Forms.Button();
            lbPlayers = new System.Windows.Forms.ListBox();
            cboPlayerFilter = new System.Windows.Forms.ComboBox();
            btnTestLogging = new System.Windows.Forms.Button();
            txtBaseballLog = new System.Windows.Forms.TextBox();
            btnClearLog = new System.Windows.Forms.Button();
            btnTestAppSetting = new System.Windows.Forms.Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            label1.Location = new System.Drawing.Point(1188, 52);
            label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label1.MinimumSize = new System.Drawing.Size(500, 385);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(500, 385);
            label1.TabIndex = 0;
            // 
            // btnGetAllLeagues
            // 
            btnGetAllLeagues.Location = new System.Drawing.Point(38, 52);
            btnGetAllLeagues.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            btnGetAllLeagues.Name = "btnGetAllLeagues";
            btnGetAllLeagues.Size = new System.Drawing.Size(250, 44);
            btnGetAllLeagues.TabIndex = 1;
            btnGetAllLeagues.Text = "Get All Leagues";
            btnGetAllLeagues.UseVisualStyleBackColor = true;
            btnGetAllLeagues.Click += btnGetAllLeagues_Click;
            // 
            // lbLeagues
            // 
            lbLeagues.FormattingEnabled = true;
            lbLeagues.ItemHeight = 25;
            lbLeagues.Location = new System.Drawing.Point(320, 52);
            lbLeagues.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            lbLeagues.Name = "lbLeagues";
            lbLeagues.Size = new System.Drawing.Size(254, 179);
            lbLeagues.TabIndex = 2;
            lbLeagues.SelectedIndexChanged += lbLeagues_SelectedIndexChanged;
            // 
            // lbTeams
            // 
            lbTeams.FormattingEnabled = true;
            lbTeams.ItemHeight = 25;
            lbTeams.Location = new System.Drawing.Point(603, 52);
            lbTeams.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            lbTeams.Name = "lbTeams";
            lbTeams.Size = new System.Drawing.Size(254, 179);
            lbTeams.TabIndex = 3;
            lbTeams.SelectedIndexChanged += lbTeams_SelectedIndexChanged;
            // 
            // listBox2
            // 
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 25;
            listBox2.Location = new System.Drawing.Point(892, 52);
            listBox2.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            listBox2.Name = "listBox2";
            listBox2.Size = new System.Drawing.Size(254, 179);
            listBox2.TabIndex = 4;
            // 
            // cboLeagues
            // 
            cboLeagues.Location = new System.Drawing.Point(0, 0);
            cboLeagues.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            cboLeagues.Name = "cboLeagues";
            cboLeagues.Size = new System.Drawing.Size(199, 33);
            cboLeagues.TabIndex = 0;
            // 
            // btnGetPlayers
            // 
            btnGetPlayers.Location = new System.Drawing.Point(38, 261);
            btnGetPlayers.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            btnGetPlayers.Name = "btnGetPlayers";
            btnGetPlayers.Size = new System.Drawing.Size(250, 44);
            btnGetPlayers.TabIndex = 5;
            btnGetPlayers.Text = "Get Players";
            btnGetPlayers.UseVisualStyleBackColor = true;
            btnGetPlayers.Click += btnGetPlayers_Click;
            // 
            // lbPlayers
            // 
            lbPlayers.FormattingEnabled = true;
            lbPlayers.ItemHeight = 25;
            lbPlayers.Location = new System.Drawing.Point(320, 262);
            lbPlayers.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            lbPlayers.Name = "lbPlayers";
            lbPlayers.Size = new System.Drawing.Size(254, 179);
            lbPlayers.TabIndex = 6;
            // 
            // cboPlayerFilter
            // 
            cboPlayerFilter.FormattingEnabled = true;
            cboPlayerFilter.Location = new System.Drawing.Point(60, 315);
            cboPlayerFilter.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            cboPlayerFilter.Name = "cboPlayerFilter";
            cboPlayerFilter.Size = new System.Drawing.Size(216, 33);
            cboPlayerFilter.TabIndex = 7;
            cboPlayerFilter.SelectedIndexChanged += cboPlayerFilter_SelectedIndexChanged;
            cboPlayerFilter.SelectionChangeCommitted += cboPlayerFilter_SelectionChangeCommitted;
            // 
            // btnTestLogging
            // 
            btnTestLogging.Location = new System.Drawing.Point(26, 473);
            btnTestLogging.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            btnTestLogging.Name = "btnTestLogging";
            btnTestLogging.Size = new System.Drawing.Size(250, 44);
            btnTestLogging.TabIndex = 10;
            btnTestLogging.Text = "Test Logging";
            btnTestLogging.UseVisualStyleBackColor = true;
            btnTestLogging.Click += btnTestLogging_Click;
            // 
            // txtBaseballLog
            // 
            txtBaseballLog.Location = new System.Drawing.Point(320, 473);
            txtBaseballLog.Multiline = true;
            txtBaseballLog.Name = "txtBaseballLog";
            txtBaseballLog.ReadOnly = true;
            txtBaseballLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            txtBaseballLog.Size = new System.Drawing.Size(772, 168);
            txtBaseballLog.TabIndex = 11;
            // 
            // btnClearLog
            // 
            btnClearLog.Location = new System.Drawing.Point(26, 529);
            btnClearLog.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            btnClearLog.Name = "btnClearLog";
            btnClearLog.Size = new System.Drawing.Size(250, 44);
            btnClearLog.TabIndex = 12;
            btnClearLog.Text = "Clear Log";
            btnClearLog.UseVisualStyleBackColor = true;
            btnClearLog.Click += btnClearLog_click;
            // 
            // btnTestAppSetting
            // 
            btnTestAppSetting.Location = new System.Drawing.Point(26, 597);
            btnTestAppSetting.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            btnTestAppSetting.Name = "btnTestAppSetting";
            btnTestAppSetting.Size = new System.Drawing.Size(250, 44);
            btnTestAppSetting.TabIndex = 13;
            btnTestAppSetting.Text = "Test appSettings";
            btnTestAppSetting.UseVisualStyleBackColor = true;
            btnTestAppSetting.Click += btnTestAppSetting_Click;
            // 
            // Main
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(1842, 1023);
            Controls.Add(btnTestAppSetting);
            Controls.Add(btnClearLog);
            Controls.Add(txtBaseballLog);
            Controls.Add(btnTestLogging);
            Controls.Add(cboPlayerFilter);
            Controls.Add(lbPlayers);
            Controls.Add(btnGetPlayers);
            Controls.Add(cboLeagues);
            Controls.Add(listBox2);
            Controls.Add(lbTeams);
            Controls.Add(lbLeagues);
            Controls.Add(btnGetAllLeagues);
            Controls.Add(label1);
            Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            Name = "Main";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnGetAllLeagues;
        private System.Windows.Forms.ListBox lbLeagues;
        private System.Windows.Forms.ListBox lbTeams;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.ComboBox cboLeagues;
        private System.Windows.Forms.Button btnGetPlayers;
        private System.Windows.Forms.ListBox lbPlayers;
        private System.Windows.Forms.ComboBox cboPlayerFilter;
        private System.Windows.Forms.Button btnTestLogging;
        private System.Windows.Forms.TextBox txtBaseballLog;
        private System.Windows.Forms.Button btnClearLog;
        private System.Windows.Forms.Button btnTestAppSetting;
    }
}

