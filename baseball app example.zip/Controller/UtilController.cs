﻿using DataManager;
using Model;
using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controller
{
    public class UtilController : iUtilController
    {
        readonly iDataManager _dataAccess;

        public UtilController(iDataManager dataAccess)
        {
            _dataAccess = dataAccess;
        }
        public UtilController()
        {
            _dataAccess = new DataManager.DataManager();
        }

        public List<PlayerFilter> LoadPlayerFilterDD()
        {
            List<PlayerFilter> list = new();
            list = _dataAccess.LoadPlayerFilterDD();

            if (list != null)
            {
                return list;
            }
            else
            {
                return new List<PlayerFilter>();
            }
            
        }

    }
}
