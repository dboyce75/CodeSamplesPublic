﻿using DataManager;
using Model;
using System;
using System.Collections.Generic;

namespace Controller
{
    public class TeamController : iTeamController
    {
        readonly iDataManager _dataAccess;
        public TeamController(iDataManager dataAccess)
        {
            _dataAccess = dataAccess;
        }
        public TeamController()
        {
            _dataAccess = new DataManager.DataManager();
        }

        public List<Player> GetAllPlayersForTeam(int teamID)
        {
            //DataManager.DataManager dm = new DataManager.DataManager(); // tightly coupled interface
            //iDataManager dm = new DataManager.DataManager();
            //iDataManager dm = DataAccessFactory.GetDataManager(); // factory pattern

            List<Player> players = new List<Player>();
            players = _dataAccess.GetAllPlayersForTeam(teamID);

            if (players != null)
            {
                return players;
            }
            else
            {
                return new List<Player>();
            }

        }

        public List<Player> GetAllPlayers(int filterFlag)
        {
            List<Player> players = new List<Player>();
            players = _dataAccess.GetAllPlayers(filterFlag);

            if (players != null)
            {
                return players;
            }
            else
            {
                return new List<Player>();
            }
            //return new List<Player>();
        }

        public List<Player> GetAllPlayers(int filterFlag, int teamID)
        {
            // this is all players on a specific team
            List<Player> players = new List<Player>();
            players = _dataAccess.GetAllPlayers(filterFlag, teamID);

            if (players != null)
            {
                return players;
            }
            else
            {
                return new List<Player>();
            }
        }

        public List<Player> GetAllPlayers(int filterFlag, int teamID, int leagueID)
        {
            // this is all FA not on a team in a specific league
            // team should probably be a list - TBD
            List<Player> players = new List<Player>();
            players = _dataAccess.GetAllPlayers(filterFlag, teamID, leagueID);

            if (players != null)
            {
                return players;
            }
            else
            {
                return new List<Player>();
            }
        }
    }
}
