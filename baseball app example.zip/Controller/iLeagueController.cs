﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace Controller
{
    public interface iLeagueController
    {
        List<League> GetAllLeagues();
        League GetOneLeague(int leagueID);
        List<Team> GetAllTeamsForLeague(int leagueID);
        
    }
}
