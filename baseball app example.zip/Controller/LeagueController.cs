﻿using System;
using System.Collections.Generic;
using DataManager;
using Model;

namespace Controller 
{
    public class LeagueController : iLeagueController
    {
        readonly iDataManager _dataAccess;
        public LeagueController(iDataManager dataAccess)
        {
            _dataAccess = dataAccess;
        }
        public LeagueController()
        {
            _dataAccess = new DataManager.DataManager();
        }

       public List<League> GetAllLeagues()
        {
            //DataManager.DataManager dm = new DataManager.DataManager();
            
            List<League> lstLeagues;
            //lstLeagues = dm.GetAllLeagues();
            lstLeagues = _dataAccess.GetAllLeagues();

            if(lstLeagues != null)
            {
                return lstLeagues;
            }
            else
            {
                return new List<League>();
            }

         }

        public League GetOneLeague(int leagueID)
        {
            //DataManager.DataManager dm = new DataManager.DataManager(); // tightly coupled interface
            //iDataManager dm = DataAccessFactory.GetDataManager(); // factory pattern

            League lg;
            lg = _dataAccess.GetOneLeague(leagueID);

            if (lg != null)
            {
                return lg;
            }
            else
            {
                return new League();
            }

        }

        public List<Team> GetAllTeamsForLeague(int leagueID)
        {
            //DataManager.DataManager dm = new DataManager.DataManager(); // tightly coupled interface
            //iDataManager dm = new DataManager.DataManager();
            //iDataManager dm = DataAccessFactory.GetDataManager(); // factory pattern

            List<Team> tms; 
            tms = _dataAccess.GetAllTeamsForLeague(leagueID);

            if (tms != null)
            {
                return tms;
            }
            else
            {
                return new List<Team>();
            }

        }

        //public class DataAccessFactory // shouldn't be needed now
        //{
        //    public static iDataManager GetDataManager()
        //    {
        //        return new DataManager.DataManager();
        //    }
        //}
    }
}
