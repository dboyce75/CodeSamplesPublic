﻿using System;

namespace Model
{
    public class League
    {
        public int LeagueID { get; set; }
        public string LeagueName { get; set; }
        public DateTime LeagueCreateDate { get; set; }

    }
}