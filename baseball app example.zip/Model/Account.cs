﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Account
    {
        public int AccountID { get; set; }
        public string  AccountName { get; set; }
        public DateTime AccountCreateDate{ get; set; }


    }
}
