﻿using System;
using System.Collections.Generic;
using Model;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using Serilog;
using Utilities;

namespace DataManager
{
    public class DataManager : iDataManager
    {

        public List<League> GetAllLeagues() 
        {

            List<League> lstLeagues = new();
            Utils uu = new();
            SqlCommand cmd;
            SqlConnection connx = new();
            
            try
            {
                using (connx = uu.GetConnection())
                {
                    using (cmd = uu.GetCommand("uspGetAllLeagues"))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection = connx;
                        cmd.CommandTimeout = 0;

                        //cmd.Parameters.Add("@ComplaintID", SqlDbType.Int).Value = Convert.ToInt32(complaintID);
                        connx.Open();
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                League league = new()
                                {
                                    LeagueID = Convert.ToInt32(dr["LeagueID"]),
                                    LeagueName = Convert.ToString(dr["LeagueName"]),
                                    LeagueCreateDate = Convert.ToDateTime(dr["LeagueCreateDate"])
                                };

                                lstLeagues.Add(league);
                            }
                        }
                    }
                }

            }
            catch (SqlException exc)
            {
                //log error
                uu.LogSqlException(ConfigurationManager.AppSettings["LogPath"], exc);

            }
            catch (Exception exc)
            {
                uu.LogException(ConfigurationManager.AppSettings["LogPath"], exc);
                throw;
            }
            finally
            {
                connx?.Close();
                connx?.Dispose();
            }
            return lstLeagues;
        }

        public League GetOneLeague(int leagueID)
        {

            League lg = new();
            Utils uu = new();
            SqlCommand cmd;
            SqlConnection connx = new(); 
            try
            {
                using (connx = uu.GetConnection())
                {
                    using (cmd = uu.GetCommand("uspGetOneLeague"))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection = connx;
                        cmd.CommandTimeout = 0;
                        cmd.Parameters.Add("@LeagueID", SqlDbType.Int).Value = Convert.ToInt32(leagueID);
                        //cmd.Parameters.Add("@ComplaintID", SqlDbType.Int).Value = Convert.ToInt32(complaintID);
                        connx.Open();
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                lg.LeagueID = Convert.ToInt32(dr["LeagueID"]);
                                lg.LeagueName = Convert.ToString(dr["LeagueName"]);
                                lg.LeagueCreateDate = Convert.ToDateTime(dr["LeagueCreateDate"]);
                            }
                        }
                    }
                }

            }
            catch (SqlException exc)
            {
                //log error
                uu.LogSqlException(ConfigurationManager.AppSettings["LogPath"], exc);

            }
            catch (Exception exc)
            {
                uu.LogException(ConfigurationManager.AppSettings["LogPath"], exc);
                throw;
            }
            finally
            {
                connx?.Close();
                connx?.Dispose();
            }
            return lg;
        }

        public List<Team> GetAllTeamsForLeague(int leagueID)
        {

            List<Team> lstTeams = new();
            Utils uu = new();
            SqlCommand cmd;
            SqlConnection connx = new();
            try
            {
                using (connx = uu.GetConnection())
                {
                    using (cmd = uu.GetCommand("uspGetAllTeamsForLeague"))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection = connx;
                        cmd.CommandTimeout = 0;

                        cmd.Parameters.Add("@LeagueID", SqlDbType.Int).Value = Convert.ToInt32(leagueID);
                        connx.Open();
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                Team tm = new()
                                {
                                    TeamID = Convert.ToInt32(dr["TeamID"]),
                                    TeamName = Convert.ToString(dr["TeamName"]),
                                    TeamWins = Convert.ToInt32(dr["TeamWins"]),
                                    TeamLosses = Convert.ToInt32(dr["TeamLosses"]),
                                    TeamTies = Convert.ToInt32(dr["TeamTies"])
                                };

                                lstTeams.Add(tm);
                            }
                        }
                    }
                }

            }
            catch (SqlException exc)
            {
                //log error
                uu.LogSqlException(ConfigurationManager.AppSettings["LogPath"], exc);

            }
            catch (Exception exc)
            {
                uu.LogException(ConfigurationManager.AppSettings["LogPath"], exc);
                throw;
            }
            finally
            {
                connx?.Close();
                connx?.Dispose();
            }
            return lstTeams;
        }

        public List<PlayerFilter> LoadPlayerFilterDD()
        {
            List<PlayerFilter> lPf = new();
            
            Utils uu = new();
            SqlCommand cmd;
            SqlConnection connx = new();
            try
            {
                using (connx = uu.GetConnection())
                {
                    using (cmd = uu.GetCommand("uspGetPlayerFilterEnums"))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection = connx;
                        cmd.CommandTimeout = 0;
                        connx.Open();
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                PlayerFilter pf = new()
                                {
                                    EnumValue = Convert.ToInt32(dr["FilterEnum"]),
                                    FilterDesc = dr["FilterDescription"].ToString()
                                };
                                lPf.Add(pf);
                            }
                        }
                    }
                }

            }
            catch (SqlException exc)
            {
                //log error
                uu.LogSqlException(ConfigurationManager.AppSettings["LogPath"], exc);

            }
            catch (Exception exc)
            {
                uu.LogException(ConfigurationManager.AppSettings["LogPath"], exc);
                throw;
            }
            finally 
            {
                connx?.Close();
                connx?.Dispose();
            }  

            return lPf;
        }
        public List<Player> GetAllPlayersForTeam(int teamID)
        {
            List<Player> lstPlayers = new(); 
            Utils uu = new();
            SqlCommand cmd;
            SqlConnection connx = new();
            try
            {
                using (connx = uu.GetConnection())
                {
                    using (cmd = uu.GetCommand("uspGetAllPlayersForTeam"))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection = connx;
                        cmd.CommandTimeout = 0;

                        cmd.Parameters.Add("@TeamID", SqlDbType.Int).Value = Convert.ToInt32(teamID);
                        connx.Open();
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                Player player = new()
                                {
                                    PlayerID = Convert.ToInt32(dr["PlayerID"]),
                                    PlayerName = Convert.ToString(dr["PlayerName"]),
                                    PlayerTeam = Convert.ToString(dr["PlayerTeam"])
                                };
                                lstPlayers.Add(player);
                            }
                        }
                    }
                }

            }
            catch (SqlException exc)
            {
                //log error
                uu.LogSqlException(ConfigurationManager.AppSettings["LogPath"], exc);

            }
            catch (Exception exc)
            {
                uu.LogException(ConfigurationManager.AppSettings["LogPath"], exc);
                throw;
            }
            finally
            {
                connx?.Close();
                connx?.Dispose();
            }
            return lstPlayers;
        }

        public List<Player> GetAllPlayers(int filterFlag)
        {

            List<Player> lstPlayers = new();
            Utils uu = new();
            SqlCommand cmd;
            SqlConnection connx = new();
            try
            {
                using (connx = uu.GetConnection())
                {
                    using (cmd = uu.GetCommand("uspGetAllPlayers"))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection = connx;
                        cmd.CommandTimeout = 0;

                        cmd.Parameters.Add("@FilterFlag", SqlDbType.Int).Value = filterFlag;
                        
                        connx.Open();
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                Player player = new()
                                {
                                    PlayerID = Convert.ToInt32(dr["PlayerID"]),
                                    PlayerName = Convert.ToString(dr["PlayerName"]),
                                    PlayerTeam = Convert.ToString(dr["PlayerTeam"])
                                };
                                lstPlayers.Add(player);
                            }
                        }
                    }
                }

            }
            catch (SqlException exc)
            {
                //log error
                uu.LogSqlException(ConfigurationManager.AppSettings["LogPath"], exc);

            }
            catch (Exception exc)
            {
                uu.LogException(ConfigurationManager.AppSettings["LogPath"], exc);
                throw;
            }
            finally
            {
                connx?.Close();
                connx?.Dispose();
            }
            return lstPlayers;
        }

        public List<Player> GetAllPlayers(int filterFlag, int teamID)
        {
            List<Player> lstPlayers = new();
            Utils uu = new();
            SqlCommand cmd;
            SqlConnection connx = new();
            try
            {
                using (connx = uu.GetConnection())
                {
                    using (cmd = uu.GetCommand("uspGetAllPlayers"))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection = connx;
                        cmd.CommandTimeout = 0;

                        cmd.Parameters.Add("@FilterFlag", SqlDbType.Int).Value = filterFlag;
                        cmd.Parameters.Add("@TeamID", SqlDbType.Int).Value = teamID;
                        connx.Open();
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                Player player = new()
                                {
                                    PlayerID = Convert.ToInt32(dr["PlayerID"]),
                                    PlayerName = Convert.ToString(dr["PlayerName"]),
                                    PlayerTeam = Convert.ToString(dr["PlayerTeam"])
                                };
                                lstPlayers.Add(player);
                            }
                        }
                    }
                }

            }
            catch (SqlException exc)
            {
                //log error
                uu.LogSqlException(ConfigurationManager.AppSettings["LogPath"], exc);

            }
            catch (Exception exc)
            {
                uu.LogException(ConfigurationManager.AppSettings["LogPath"], exc);
                throw;
            }
            finally
            {
                connx?.Close();
                connx?.Dispose();
            }
            return lstPlayers;
        }
        public List<Player> GetAllPlayers(int filterFlag, int teamID, int leagueID)
        {
            List<Player> lstPlayers = new();
            Utils uu = new();
            SqlCommand cmd;
            SqlConnection connx = new();
            try
            {
                using (connx = uu.GetConnection())
                {
                    using (cmd = uu.GetCommand("uspGetAllPlayers"))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection = connx;
                        cmd.CommandTimeout = 0;

                        cmd.Parameters.Add("@FilterFlag", SqlDbType.Int).Value = filterFlag;
                        cmd.Parameters.Add("@TeamID", SqlDbType.Int).Value = teamID;
                        cmd.Parameters.Add("@LeagueID", SqlDbType.Int).Value = leagueID;
                        connx.Open();
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                Player player = new()
                                {
                                    PlayerID = Convert.ToInt32(dr["PlayerID"]),
                                    PlayerName = Convert.ToString(dr["PlayerName"]),
                                    PlayerTeam = Convert.ToString(dr["PlayerTeam"])
                                };
                                lstPlayers.Add(player);
                            }
                        }
                    }
                }

            }
            catch (SqlException exc)
            {
                //log error
                uu.LogSqlException(ConfigurationManager.AppSettings["LogPath"], exc);

            }
            catch (Exception exc)
            {
                uu.LogException(ConfigurationManager.AppSettings["LogPath"], exc);
                throw;
            }
            finally
            {
                connx?.Close();
                connx?.Dispose();
            }
            return lstPlayers;
        }
       
    }
}
