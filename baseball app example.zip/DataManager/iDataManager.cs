﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace DataManager
{
    public interface iDataManager
    {
        List<League> GetAllLeagues();
        League GetOneLeague(int leagueID);
        List<Team> GetAllTeamsForLeague(int leagueID);
        List<Player> GetAllPlayersForTeam(int teamID);
        List<Player> GetAllPlayers(int filterFlag);
        List<Player> GetAllPlayers(int filterFlag, int teamID);
        List<Player> GetAllPlayers(int filterFlag, int teamID, int leagueID);
        List<PlayerFilter> LoadPlayerFilterDD();


    }
}
