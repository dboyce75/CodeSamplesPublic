﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Team
    {
        public int TeamId { get; set; }
        public string? TeamName { get; set; }
        public string? TeamLogo { get; set; }
        public int? TeamWins { get; set; }
        public int? TeamLosses  { get; set; }
        public int? TeamTies { get; set; }
        public int TeamAccount { get; set; }

    }
}
