﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SystemFrameworks;
using DataLayer;


namespace BusinessLayer
{
    public class BusinessManager : IBusiness
    {
        DataManager iDo = new DataManager();

        public List<ItemToInvoice> GetItemsToInvoice(string strRunAsOf)
        {
            return iDo.GetItemsToInvoice(strRunAsOf);
        }

        public void FinalizeInvoices(List<ItemToInvoice> lstItemToInvoice)
        {
            iDo.FinalizeInvoices(lstItemToInvoice);
        }
        
        public void UpdateLoadingData(string strOrderNumber, string strReturnValue)
        {
            iDo.UpdateLoadingData(strOrderNumber, strReturnValue);
        }

        public List<ItemToInvoice> CallSageInvoicing(List<ItemToInvoice> lstItemToInvoice)
        {
            return new List<ItemToInvoice>();
        }
    }
}
