﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using BusinessLayer;
using System.Globalization;

using SystemFrameworks;
using extadProxy;




namespace BatchInvoicing
{
    class BatchInvoicing
    {
        

        static void Main(string[] args)
        {
            BusinessManager iBo = new BusinessManager();
            string wrkOrderNumber = "";
            try
            {
                // this is the thread exception handler
                AppDomain curDomain = AppDomain.CurrentDomain;
                curDomain.UnhandledException += new UnhandledExceptionEventHandler(BatchInvoicing_UnhandledException);
                // get date from commandline args
                string runAsOf = "";

                if (args.Length > 0)
                {
                    string[] formats= {"M/d/yyyy","MM/dd/yyyy"};
                    DateTime dateValue;
                    // date validation maybe
                    if (DateTime.TryParseExact(args[0], formats, new CultureInfo("en-US"),DateTimeStyles.None, out dateValue))
                    {
                    // date parameter passed in
                        runAsOf = args[0];
                    } 
                    else {
                        Console.WriteLine("Invalid date command argument!");
                    }
                }
                // manual run
                /*
                 extadProxy.extadinvoice extInvManual = new extadProxy.extadinvoice();
                 extInvManual.CBATCHNO = "ADPT000002";
                 extInvManual.CCUSTNO = "101111";
                 extInvManual.CORNUM = "525909";
                 extInvManual.CSHIPDATE = "";
                 string retVal2 = extInvManual.eadinv();
               */
               // end manual run

                // get list of records to invoice
                List<ItemToInvoice> lstItemsToInvoice = iBo.GetItemsToInvoice(runAsOf);
                // iterate through the list and call the sage component
                
                if (lstItemsToInvoice.Count > 0)
                {
                    int counter = 0;
                    
                    foreach (ItemToInvoice itm in lstItemsToInvoice)
                    {
                        if (counter > Convert.ToInt32(ConfigurationManager.AppSettings["BatchAmount"]))
                        { 
                            break;
                        }
                        extadProxy.extadinvoice extInv = new extadProxy.extadinvoice();
                        extInv.CBATCHNO = itm.BatchID;
                        extInv.CCUSTNO = itm.CustomerNumber;
                        extInv.CORNUM = itm.OrderNumber;
                        wrkOrderNumber = itm.OrderNumber;
                        extInv.CSHIPDATE = itm.RequestedShipDate;
                        string retVal = extInv.eadinv();
                        // probably don't need this string returnfield = extInv.CRETURN;
                        // extInv.SHIPVIA / extInv.INVNO not in model
                        // call sage comp
                        if (retVal.Contains("ERROR"))
                        {

                        }
                        else // success!
                        {

                        }

                        // check results
                        
                        // update record with results
                        iBo.UpdateLoadingData(itm.OrderNumber, retVal);
                        counter++;
                        // SLEEEEEEEEEEEEEEEEP!
                        System.Threading.Thread.Sleep(Convert.ToInt32(ConfigurationManager.AppSettings["SageDLLSleepTimer"].ToString()));
                    }
                    iBo.FinalizeInvoices(lstItemsToInvoice);

                }
                // finalize


            }
            catch (Exception ex)
            {
                Utilities.GenerateCaughtException("Generic Unhandled exception occurred", ex, wrkOrderNumber);
                // adding this to finalize any orders that complete before an unhandled DLL exception
                List<ItemToInvoice> lstItemsToInvoice = new List<ItemToInvoice>();
                iBo.FinalizeInvoices(lstItemsToInvoice);
            }
            finally
            {
                Console.WriteLine("Fin.");
            }


        }

        

        static void BatchInvoicing_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            // this is to catch any exceptions in threading
            Console.WriteLine("in Unhandled exception block");
        }
    }
}
