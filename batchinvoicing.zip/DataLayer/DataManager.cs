﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SystemFrameworks;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


namespace DataLayer
{
    public class DataManager : IData
    {
        public List<ItemToInvoice> GetItemsToInvoice(string strRunAsOf)
        {
            List<ItemToInvoice> lstItems = new List<ItemToInvoice>();
            SqlCommand cmd = null;
            SqlConnection connx = null;
            try
            {
                using (connx = getConnection())
                {
                    using (cmd = new SqlCommand("Dataload.PickTicketInsertScrub"))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection = connx;
                        cmd.CommandTimeout = 0;
                        if (strRunAsOf != "")
                        {
                            cmd.Parameters.Add("@RunDate", SqlDbType.VarChar).Value = strRunAsOf;
                        }
                        cmd.Parameters.Add("@Section", SqlDbType.VarChar).Value = "Invoicing";
                        connx.Open();
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                ItemToInvoice itm = new ItemToInvoice();
                                itm.CustomerNumber = dr["CustNo"].ToString();
                                itm.OrderNumber = dr["OrderNo"].ToString();
                                itm.BatchID = dr["BatchID"].ToString();
                                itm.RequestedShipDate = dr["ReqShipDate"].ToString();
                                itm.FDMFlag = Convert.ToBoolean(dr["FDMFlag"].ToString());
                                lstItems.Add(itm);
                            }
                        }
                    }
                }

            }
            catch (Exception exc)
            {
                Utilities.GenerateCaughtException("Get Items to Invoice", exc);
            }
            finally
            {

            }
            return lstItems;
        }

        public void UpdateLoadingData(string strOrderNumber, string strReturnValue)
        {

            SqlCommand cmd = null;
            SqlConnection connx = null;
            string retVal = "";
            try
            {
                using (connx = getConnection())
                {
                    using (cmd = new SqlCommand("Dataload.PickTicketUpdate"))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection = connx;
                        cmd.CommandTimeout = 0;
                        cmd.Parameters.Add("@OrderNo", SqlDbType.VarChar).Value = strOrderNumber;
                        cmd.Parameters.Add("@Message", SqlDbType.VarChar).Value = strReturnValue;
                        
                        connx.Open();
                        retVal = cmd.ExecuteNonQuery().ToString();

                    }
                }

            }
            catch (Exception exc)
            {
                Utilities.GenerateCaughtException("Update Loading Data", exc);
            }
            finally
            {

            }

        }
        public void FinalizeInvoices(List<ItemToInvoice> lstItemToInvoice)
        {
            SqlCommand cmd = null;
            SqlConnection connx = null;
            string retVal = "";
            try
            {
                using (connx = getConnection())
                {
                    using (cmd = new SqlCommand("Dataload.PickTicketFinalize"))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection = connx;
                        cmd.CommandTimeout = 0;
                        connx.Open();

                        retVal = cmd.ExecuteNonQuery().ToString();
                    }
                }
                Console.WriteLine(retVal + " rows Finalized");
            }
            catch (Exception ex)
            {
                
                Utilities.GenerateCaughtException("Data Layer - Finalize Orders ", ex);
            }
        }

        private SqlConnection getConnection()
        {
            string cxString = ConfigurationManager.ConnectionStrings["DWConnx"].ConnectionString;
            SqlConnection connx = new SqlConnection(cxString);
            return connx;
        }

        //private SqlCommand getCommand(string sectionName)
        //{
        //    SqlCommand cmd = new SqlCommand("stored proc name nere");
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    cmd.Parameters.Add("@Section", SqlDbType.VarChar).Value = sectionName;
        //    return cmd;

        //}
    }
}
