﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SystemFrameworks;

namespace DataLayer
{
    interface IData
    {
        List<ItemToInvoice> GetItemsToInvoice(string strRunAsOf);
        void FinalizeInvoices(List<ItemToInvoice> lstItemToInvoice);
        void UpdateLoadingData(string strOrderNumber, string strReturnValue);
        
    }
}
