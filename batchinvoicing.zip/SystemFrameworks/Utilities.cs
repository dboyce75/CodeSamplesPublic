﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;
using System.Configuration;

namespace SystemFrameworks
{
    public static class Utilities
    {
        public static void GenerateCaughtException(string callingMethod, Exception ex, string optionalOrderNo="")
        {
            // Logging ?
            MailMessage msg = null;
            try
            {
                msg = new MailMessage();
                string msgTo = ConfigurationManager.AppSettings["EmailTo"];
                foreach (var emailto in msgTo.Split(new[] { ";" }, StringSplitOptions.RemoveEmptyEntries))
                {
                    msg.To.Add(emailto);
                }
                StringBuilder message = new StringBuilder();
                message.Append("An Exception occured in Batch Invoicing" + Environment.NewLine);
                if (optionalOrderNo != "")
                {
                    message.Append("Order Number: " + optionalOrderNo + Environment.NewLine);
                }
                message.Append(callingMethod + Environment.NewLine);
                message.Append(ex.Message + Environment.NewLine);
                message.Append(ex.StackTrace);
                msg.Body = message.ToString();
                msg.IsBodyHtml = false;
                msg.Subject = "ACCUDART BATCH INVOICING : Unhandled non threaded exception occurred " + ConfigurationManager.AppSettings["Environment"];
                msg.From = new MailAddress(ConfigurationManager.AppSettings["EmailFrom"]);


                SmtpClient client = new SmtpClient("192.168.20.20", 25);

                using (client)
                {
                    try
                    {
                        client.Send(msg);
                    }

                    catch (Exception exc) { }

                }
            }
            finally { msg.Dispose(); }
        }
    }
}
