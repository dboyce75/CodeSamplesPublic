﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SystemFrameworks
{
    public class ItemToInvoice
    {
        public string OrderNumber { get; set; }
        public string CustomerNumber { get; set; }
        public string BatchID { get; set; }
        public string RequestedShipDate { get; set; }
        public bool FDMFlag { get; set; }
        public bool ExcludeFlag { get; set; }
        public string UserName { get; set; }


    }
}
